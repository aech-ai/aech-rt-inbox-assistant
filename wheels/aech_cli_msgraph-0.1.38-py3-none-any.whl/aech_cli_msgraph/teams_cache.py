import json
import os
from datetime import datetime, timedelta, timezone

class TeamsMessageCache:
    """Cache for tracking seen Teams messages to prevent duplicates during polling."""
    
    def __init__(self, cache_file="teams_messages_cache.json", expiry_days=7):
        self.cache_file = cache_file
        self.expiry_days = expiry_days
        self.cache = self._load_cache()
    
    def _load_cache(self):
        """Load cache from file or create new cache structure."""
        if os.path.exists(self.cache_file):
            try:
                with open(self.cache_file, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError):
                # If cache is corrupted, start fresh
                return {"seen_messages": {}, "last_poll": None}
        return {"seen_messages": {}, "last_poll": None}
    
    def _save_cache(self):
        """Save cache to file."""
        try:
            cache_dir = os.path.dirname(self.cache_file)
            if cache_dir:
                os.makedirs(cache_dir, exist_ok=True)

            with open(self.cache_file, 'w') as f:
                json.dump(self.cache, f, indent=2)
        except IOError as e:
            # If we can't save, just continue (cache will be lost on restart)
            print(f"Warning: Could not save Teams message cache: {e}")
    
    def mark_seen(self, message_id, timestamp):
        """Mark a message as seen with its timestamp."""
        self.cache["seen_messages"][message_id] = timestamp
        self.cache["last_poll"] = datetime.now(timezone.utc).isoformat()
        self._cleanup_old_entries()
        self._save_cache()
    
    def mark_batch_seen(self, messages):
        """Mark multiple messages as seen at once (more efficient than individual calls)."""
        for message_id, timestamp in messages:
            self.cache["seen_messages"][message_id] = timestamp
        self.cache["last_poll"] = datetime.now(timezone.utc).isoformat()
        self._cleanup_old_entries()
        self._save_cache()
    
    def is_seen(self, message_id):
        """Check if a message has been seen before."""
        return message_id in self.cache["seen_messages"]
    
    def _cleanup_old_entries(self):
        """Remove entries older than expiry_days to prevent unbounded growth."""
        cutoff = (datetime.now(timezone.utc) - timedelta(days=self.expiry_days)).isoformat()
        self.cache["seen_messages"] = {
            k: v for k, v in self.cache["seen_messages"].items() 
            if v > cutoff
        }
    
    def reset(self):
        """Clear cache contents and persist."""
        self.cache = {"seen_messages": {}, "last_poll": None}
        self._save_cache()
    
    def get_last_poll_time(self):
        """Get the timestamp of the last poll."""
        return self.cache.get("last_poll")
