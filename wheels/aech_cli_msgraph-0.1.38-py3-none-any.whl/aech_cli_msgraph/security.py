import re


class OutboundNotAllowedError(Exception):
    """Raised when attempting to send to a recipient not in the outbound whitelist."""

    pass


def is_whitelisted(sender_email: str, whitelist: list[str]) -> bool:
    """
    Checks if the sender_email is in the whitelist.
    Whitelist items can be:
    - A full email address (e.g., "bob@example.com")
    - A domain starting with @ (e.g., "@example.com")
    """
    if not sender_email:
        return False
        
    sender_email = sender_email.lower()
    
    for item in whitelist:
        item = item.lower()
        if item.startswith("@"):
            if sender_email.endswith(item):
                return True
        else:
            if sender_email == item:
                return True
    return False

def is_blacklisted(sender_email: str, blacklist: list[str]) -> bool:
    """
    Checks if the sender_email matches any pattern in the blacklist.
    """
    if not sender_email:
        return False
        
    sender_email = sender_email.lower()
    
    for pattern in blacklist:
        if re.match(pattern, sender_email, re.IGNORECASE):
            return True
    return False

def verify_email_auth(headers: list) -> dict:
    """
    Parses InternetMessageHeaders to check for Authentication-Results.
    Returns a dict with status of spf, dkim, and dmarc.
    """
    results = {
        "spf": "none",
        "dkim": "none",
        "dmarc": "none",
        "overall_pass": False
    }
    
    auth_header = next((h['value'] for h in headers if h['name'].lower() == 'authentication-results'), None)
    
    if not auth_header:
        # If no header, we can't verify, so we default to fail/none.
        # However, internal emails might not have this.
        return results

    auth_header = auth_header.lower()
    
    # Simple regex to find pass/fail status
    # Note: This is a basic parser. Real-world headers can be complex.
    
    if "spf=pass" in auth_header:
        results["spf"] = "pass"
    elif "spf=fail" in auth_header:
        results["spf"] = "fail"
        
    if "dkim=pass" in auth_header:
        results["dkim"] = "pass"
    elif "dkim=fail" in auth_header:
        results["dkim"] = "fail"

    if "dmarc=pass" in auth_header:
        results["dmarc"] = "pass"
    elif "dmarc=fail" in auth_header:
        results["dmarc"] = "fail"
        
    # Strict check: If any of them explicitly FAIL, we consider it a fail.
    # If at least one PASSes and none FAIL, we consider it a pass.
    # (This is a simplified policy)
    
    has_fail = "fail" in [results["spf"], results["dkim"], results["dmarc"]]
    has_pass = "pass" in [results["spf"], results["dkim"], results["dmarc"]]
    
    results["overall_pass"] = has_pass and not has_fail

    return results


def check_outbound_allowed(recipient_email: str, whitelist: list[str]) -> None:
    """Check if sending to recipient is allowed. Raises OutboundNotAllowedError if not.

    Args:
        recipient_email: Email address of the recipient
        whitelist: List of allowed emails/domains (e.g., ["@aech.ai", "bob@example.com"])

    Raises:
        OutboundNotAllowedError: If recipient is not in the whitelist
    """
    if not recipient_email:
        raise OutboundNotAllowedError("Recipient email is empty")

    if not is_whitelisted(recipient_email, whitelist):
        raise OutboundNotAllowedError(
            f"Sending to '{recipient_email}' is not allowed. "
            f"Recipient not in outbound whitelist."
        )
