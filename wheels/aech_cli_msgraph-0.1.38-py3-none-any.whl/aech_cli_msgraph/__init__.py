# This package provides a CLI for Microsoft Graph operations
