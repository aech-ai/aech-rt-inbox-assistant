import os
import atexit
import msal
from .config import CLIENT_ID, AUTHORITY, SCOPES, CACHE_FILE

class AuthManager:
    def __init__(self):
        self.cache = msal.SerializableTokenCache()
        # Ensure cache directory exists for package installs (wheel)
        cache_dir = os.path.dirname(CACHE_FILE)
        if cache_dir:
            os.makedirs(cache_dir, exist_ok=True)

        if os.path.exists(CACHE_FILE):
            self.cache.deserialize(open(CACHE_FILE, "r").read())
        
        # Save cache on exit
        atexit.register(lambda: open(CACHE_FILE, "w").write(self.cache.serialize()) if self.cache.has_state_changed else None)

        self.app = msal.PublicClientApplication(
            CLIENT_ID,
            authority=AUTHORITY,
            token_cache=self.cache
        )

    def get_token(self):
        accounts = self.app.get_accounts()
        result = None
        
        if accounts:
            # Try to get token silently
            result = self.app.acquire_token_silent(SCOPES, account=accounts[0])
        
        if not result:
            # No token found or silent acquisition failed
            return None
            
        return result

    def initiate_device_flow(self):
        flow = self.app.initiate_device_flow(scopes=SCOPES)
        if "user_code" not in flow:
            raise ValueError("Fail to create device flow. Err: %s" % flow)
        return flow

    def acquire_token_by_device_flow(self, flow):
        result = self.app.acquire_token_by_device_flow(flow)
        return result

    def logout(self):
        accounts = self.app.get_accounts()
        if accounts:
            for account in accounts:
                self.app.remove_account(account)
            if os.path.exists(CACHE_FILE):
                os.remove(CACHE_FILE)
            return True
        return False
