"""
Utility helpers for converting between Markdown and HTML using Pandoc.
"""

from __future__ import annotations

import warnings
try:
    import pypandoc
except ImportError:  # pragma: no cover - dependency is optional at import time
    pypandoc = None  # type: ignore
    warnings.warn("pypandoc is not installed; Pandoc conversions will be skipped.")

_PANDOC_AVAILABLE = False
if pypandoc:
    try:
        # Validate that the Pandoc binary is reachable once at import time.
        pypandoc.get_pandoc_version()
        _PANDOC_AVAILABLE = True
    except OSError:
        warnings.warn("Pandoc executable is not available; conversions will be skipped.")


def _convert(text: str, to_format: str, from_format: str) -> str:
    """
    Convert text using Pandoc if available, otherwise return the original text.
    """
    if not text:
        return ""

    if not _PANDOC_AVAILABLE:
        return text

    try:
        return pypandoc.convert_text(text, to_format, format=from_format)
    except Exception:
        # Fall back to the original content if Pandoc raises an error.
        return text


def html_to_markdown(html: str) -> str:
    """
    Convert HTML to GitHub-Flavored Markdown.
    """
    return _convert(html, "gfm", "html").strip()


def markdown_to_html(markdown_text: str) -> str:
    """
    Convert Markdown to HTML using Pandoc.
    """
    return _convert(markdown_text, "html", "gfm")
