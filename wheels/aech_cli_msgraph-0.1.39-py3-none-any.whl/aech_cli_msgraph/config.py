import os
import json
import sys
from pathlib import Path

# Note: No load_dotenv() here - environment should be set by the caller
# (Docker env_file, shell export, etc.), not loaded from .env by the library.

# Debug logging - set MSGRAPH_DEBUG=1 to enable verbose API call tracing
DEBUG = os.getenv("MSGRAPH_DEBUG", "").lower() in ("1", "true", "yes")

def debug_log(msg: str) -> None:
    """Print debug message to stderr if DEBUG is enabled."""
    if DEBUG:
        print(f"[DEBUG] {msg}", file=sys.stderr)

# Azure App Registration Config
CLIENT_ID = os.getenv("AZURE_CLIENT_ID")
TENANT_ID = os.getenv("AZURE_TENANT_ID", "common")
AUTHORITY = f"https://login.microsoftonline.com/{TENANT_ID}"

# Scopes for Microsoft Graph API
# Override via MSGRAPH_SCOPES env var (comma-separated)
# Must match what's configured in the Azure App Registration
# Note: openid, profile, offline_access are automatically added by MSAL
DEFAULT_SCOPES = "User.Read,Mail.ReadWrite,Mail.Send,MailboxSettings.Read"
_scopes_str = os.getenv("MSGRAPH_SCOPES", DEFAULT_SCOPES)
SCOPES = [s.strip() for s in _scopes_str.split(",") if s.strip()]

# Access Control - Load from JSON
# Loaded lazily to avoid import-time failures (e.g., during manifest generation)

class AccessControlError(Exception):
    """Raised when access control configuration is missing or invalid."""
    pass


_ACCESS_CONTROL_CACHE: dict | None = None


def _resolve_access_control_path() -> Path:
    """Resolve the access control config path with sensible fallbacks."""
    env_path = os.getenv("MSGRAPH_ACCESS_CONTROL_PATH")
    if env_path:
        return Path(env_path)

    aech_path = os.getenv("AECH_ACCESS_CONTROL_PATH")
    if aech_path:
        return Path(aech_path)

    candidates = [
        Path("data/access_control.json"),
        Path(".data/access_control.json"),
        Path("../data/access_control.json"),
        Path("../.data/access_control.json"),
    ]
    for candidate in candidates:
        if candidate.is_file():
            return candidate

    return Path("data/access_control.json")


def _load_access_control() -> dict:
    """Load access control configuration from JSON file.

    Fails loudly if config is missing or invalid.
    Results are cached after first load.

    Schema:
    {
        "root": ["*@aech.ai"],
        "users": ["*@clientcorp.com", "vip@gmail.com"],
        "recipients": ["*@vendor.com"],
        "roles": {
            "admin": ["*@aech.ai"],
            "user": ["*@clientcorp.com"]
        }
    }

    - root: System owners (can message agent + receive messages)
    - users: People who use the agent (can message agent + receive messages)
    - recipients: People the agent can send to (receive only)
    - roles: Application-level permissions (admin/user) - placeholder for future use

    All lists support:
    - "*@domain.com" for all users at a domain
    - "user@domain.com" for specific users
    """
    global _ACCESS_CONTROL_CACHE
    if _ACCESS_CONTROL_CACHE is not None:
        return _ACCESS_CONTROL_CACHE

    access_control_path = _resolve_access_control_path()

    if not access_control_path.exists():
        raise AccessControlError(
            f"Access control config not found: {access_control_path}\n"
            f"Please create this file. See access_control.json.template"
        )

    if access_control_path.is_dir():
        raise AccessControlError(
            f"Access control config path is a directory: {access_control_path}\n"
            "Expected a JSON file. Remove the directory or point "
            "MSGRAPH_ACCESS_CONTROL_PATH to the correct file."
        )

    try:
        with open(access_control_path) as f:
            config = json.load(f)
    except Exception as e:
        raise AccessControlError(f"Failed to parse access control config: {e}")


    if "root" not in config:
        raise AccessControlError("Missing 'root' in access_control.json")

    _ACCESS_CONTROL_CACHE = config
    return config


def _normalize_pattern(pattern: str) -> str:
    """Normalize a pattern for whitelist matching.

    Converts *@domain.com to @domain.com for security.py compatibility.
    Keeps exact addresses as-is.
    """
    if pattern.startswith("*@"):
        return pattern[1:]  # "*@domain.com" -> "@domain.com"
    return pattern


def _build_whitelist(include_recipients: bool = False) -> list:
    """Build whitelist from access control config.

    Args:
        include_recipients: If True, include recipients (for outgoing)

    Returns:
        List of whitelist patterns (e.g., ["@aech.ai", "user@example.com"])
    """
    config = _load_access_control()
    whitelist = []

    # 1. Root users are always allowed
    for pattern in config.get("root", []):
        whitelist.append(_normalize_pattern(pattern))

    # 2. Users can send AND receive
    for pattern in config.get("users", []):
        whitelist.append(_normalize_pattern(pattern))

    # 3. Recipients can only receive (outgoing only)
    if include_recipients:
        for pattern in config.get("recipients", []):
            whitelist.append(_normalize_pattern(pattern))

    return whitelist


def get_email_whitelist_incoming() -> list:
    """Get incoming whitelist (who can message the agent). Lazy loaded."""
    return _build_whitelist(include_recipients=False)


def get_email_whitelist_outgoing() -> list:
    """Get outgoing whitelist (who the agent can message). Lazy loaded."""
    return _build_whitelist(include_recipients=True)

# Email Blacklist - keep hardcoded system patterns
EMAIL_BLACKLIST = [
    r"^MicrosoftExchange.*@.*", # Ignore internal Exchange addresses
]

# Email authentication filtering strictness
# Set to "true" to drop emails that fail SPF/DKIM/DMARC checks
# Defaults: Only DMARC failures cause drops, SPF/DKIM failures generate warnings
EMAIL_AUTH_DROP_SPF_FAIL = os.getenv("EMAIL_AUTH_DROP_SPF_FAIL", "false").lower() in ("1", "true", "yes")
EMAIL_AUTH_DROP_DKIM_FAIL = os.getenv("EMAIL_AUTH_DROP_DKIM_FAIL", "false").lower() in ("1", "true", "yes")
EMAIL_AUTH_DROP_DMARC_FAIL = os.getenv("EMAIL_AUTH_DROP_DMARC_FAIL", "true").lower() in ("1", "true", "yes")

AUTH_NOTIFICATION_URL = os.getenv("MSGRAPH_AUTH_NOTIFICATION_URL")

# Teams polling configuration
TEAMS_POLL_INTERVAL_S = 30  # Default polling interval in seconds
TEAMS_CACHE_FILE = os.path.join("/data", "app_context", "aech-cli-msgraph", "teams_messages_cache.json")
TEAMS_CACHE_EXPIRY_DAYS = 7

# Reactions (defaults can be overridden via env)
REACTION_PROCESSING = os.getenv("MSGRAPH_REACTION_PROCESSING", "🤖")
REACTION_DONE = os.getenv("MSGRAPH_REACTION_DONE", "✅")
REACTION_ERROR = os.getenv("MSGRAPH_REACTION_ERROR", "❌")

# Token cache path
# - Override with MSGRAPH_TOKEN_CACHE_PATH
# - Default to container mount: /data/app_context/aech-cli-msgraph/token_cache.json
DEFAULT_CACHE_PATH = os.path.join(
    "/data",
    "app_context",
    "aech-cli-msgraph",
    "token_cache.json",
)
CACHE_FILE = os.getenv("MSGRAPH_TOKEN_CACHE_PATH", DEFAULT_CACHE_PATH)
