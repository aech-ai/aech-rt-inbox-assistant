import asyncio
import json
import logging
import os
import sys
import time as time_module
from datetime import datetime, timedelta, timezone as dt_timezone
from typing import Any
from zoneinfo import ZoneInfo
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

import typer

# Set up logger for this module
logger = logging.getLogger(__name__)
import requests
from azure.core.credentials import AccessToken
from msgraph import GraphServiceClient
from msgraph.generated.users.item.presence.set_presence.set_presence_post_request_body import SetPresencePostRequestBody
from msgraph.generated.users.item.presence.set_status_message.set_status_message_post_request_body import SetStatusMessagePostRequestBody
from msgraph.generated.models.presence_status_message import PresenceStatusMessage
from msgraph.generated.models.item_body import ItemBody
from msgraph.generated.models.body_type import BodyType
from msgraph.generated.models.date_time_time_zone import DateTimeTimeZone

from .auth import AuthManager
from .graph import GraphClient
from .pandoc_utils import html_to_markdown


app = typer.Typer(
    help="Privileged Microsoft 365 Graph interface for Agent Aech. Poll and send mail, Teams, calendar, and OneDrive content with rich JSON for agent workflows; Pandoc is used to convert HTML bodies to Markdown when available."
)

# Lazy auth_manager to ensure env vars are read at call time, not import time
_auth_manager = None

def get_auth_manager():
    global _auth_manager
    if _auth_manager is None:
        _auth_manager = AuthManager()
    return _auth_manager


def resolve_flag_due(due_str: str, timezone_iana: str):
    """Convert relative date string to Graph API flag datetime objects.

    Args:
        due_str: 'today', 'tomorrow', 'this-week', 'next-week', or ISO-8601 date
        timezone_iana: User's timezone in IANA format (e.g., 'America/Los_Angeles')

    Returns:
        Tuple of (start_datetime, due_datetime) dicts for Graph API
    """
    tz = ZoneInfo(timezone_iana)
    today = datetime.now(tz)

    if due_str.lower() == "today":
        start = today.replace(hour=8, minute=0, second=0, microsecond=0)
        end = today.replace(hour=17, minute=0, second=0, microsecond=0)
    elif due_str.lower() == "tomorrow":
        tomorrow = today + timedelta(days=1)
        start = tomorrow.replace(hour=8, minute=0, second=0, microsecond=0)
        end = tomorrow.replace(hour=17, minute=0, second=0, microsecond=0)
    elif due_str.lower() == "this-week":
        # Friday of current week
        days_until_friday = (4 - today.weekday()) % 7
        if days_until_friday == 0 and today.hour >= 17:
            days_until_friday = 7  # Already past Friday 5pm, go to next week
        friday = today + timedelta(days=days_until_friday)
        start = today.replace(hour=8, minute=0, second=0, microsecond=0)
        end = friday.replace(hour=17, minute=0, second=0, microsecond=0)
    elif due_str.lower() == "next-week":
        # Friday of next week
        days_until_friday = (4 - today.weekday()) % 7 + 7
        friday = today + timedelta(days=days_until_friday)
        start = today.replace(hour=8, minute=0, second=0, microsecond=0)
        end = friday.replace(hour=17, minute=0, second=0, microsecond=0)
    else:
        # Assume ISO-8601 date or datetime
        try:
            if "T" in due_str:
                end = datetime.fromisoformat(due_str.replace("Z", "+00:00"))
            else:
                end = datetime.fromisoformat(due_str).replace(hour=17, minute=0)
            if end.tzinfo is None:
                end = end.replace(tzinfo=tz)
            start = end.replace(hour=8, minute=0)
        except ValueError as e:
            raise ValueError(f"Invalid date format: {due_str}. Use ISO-8601 or: today, tomorrow, this-week, next-week") from e

    def to_graph_datetime(dt: datetime, tz_name: str):
        return {
            "dateTime": dt.strftime("%Y-%m-%dT%H:%M:%S"),
            "timeZone": tz_name
        }

    return (
        to_graph_datetime(start, timezone_iana),
        to_graph_datetime(end, timezone_iana)
    )


@app.command(hidden=True)
def login():
    """Authenticate with Microsoft Graph."""

    # Check if already logged in
    if get_auth_manager().get_token():
        print("Already logged in!")
        return

    flow = get_auth_manager().initiate_device_flow()

    # Send notification to Teams if configured
    from .config import AUTH_NOTIFICATION_URL
    import requests

    if AUTH_NOTIFICATION_URL:
        try:
            user_code = flow["user_code"]
            verification_uri = flow["verification_uri"]

            card = {
                "type": "message",
                "attachments": [
                    {
                        "contentType": "application/vnd.microsoft.card.adaptive",
                        "content": {
                            "$schema": "http://adaptivecards.io/schemas/adaptive-card.json",
                            "type": "AdaptiveCard",
                            "version": "1.2",
                            "body": [
                                {
                                    "type": "TextBlock",
                                    "text": "Agent Aech Login Required",
                                    "size": "Large",
                                    "weight": "Bolder"
                                },
                                {
                                    "type": "TextBlock",
                                    "text": f"Please sign in to authorize the CLI using code: **{user_code}**",
                                    "wrap": True
                                }
                            ],
                            "actions": [
                                {
                                    "type": "Action.OpenUrl",
                                    "title": "Login & Authorize",
                                    "url": verification_uri
                                }
                            ]
                        }
                    }
                ]
            }
            requests.post(AUTH_NOTIFICATION_URL, json=card)
            print("Notification sent to Teams.")
        except Exception as e:
            print(f"Failed to send Teams notification: {e}")

    print(f"Device Code Login:\n{flow['message']}")

    result = get_auth_manager().acquire_token_by_device_flow(flow)
    if "access_token" in result:
        print("Login successful!")
    else:
        print(f"Login failed: {result.get('error_description')}")

@app.command(hidden=True)
def logout():
    """Clear local token cache."""
    if get_auth_manager().logout():
        print("Logged out successfully.")
    else:
        print("No active session found.")

@app.command(hidden=True)
def me(json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")):
    """Get current user profile."""
    try:
        client = GraphClient()
        user = client.get_me()

        # Try to get timezone
        tz_data = None
        try:
            tz_data = client.get_timezone()
        except:
            pass

        if json_output:
            user['timezone'] = tz_data
            print(json.dumps(user, indent=2))
        else:
            print(f"Hello, {user.get('displayName')}!")
            print(f"Email: {user.get('mail') or user.get('userPrincipalName')}")
            print(f"ID: {user.get('id')}")
            tz_display = tz_data['iana'] if tz_data else "Unknown"
            print(f"Timezone: {tz_display}")
    except Exception as e:
        print(f"Error: {e}")

@app.command(hidden=True)
def timezone(
    user_email: str = typer.Argument(None, help="Email of the user to check timezone for. Defaults to me."),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """Get timezone for a user. Returns both Windows and IANA formats."""
    try:
        client = GraphClient()
        tz_data = client.get_timezone(user_email)

        if json_output:
            print(json.dumps(tz_data, indent=2))
        else:
            target = user_email if user_email else "Me"
            print(f"Timezone for {target}: {tz_data['iana']} ({tz_data['windows']})")
    except Exception as e:
        print(f"Error: {e}")

@app.command(hidden=True)
def chats(json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")):
    """List recent chats."""
    try:
        client = GraphClient()
        chats = client.get_teams_messages()

        if json_output:
            print(json.dumps(chats.get('value', []), indent=2))
        else:
            print("Recent Chats:")
            print(f"{'Topic':<40} {'Type':<15} {'Last Updated':<25}")
            print("-" * 80)

            for chat in chats.get('value', []):
                topic = chat.get('topic')
                if not topic:
                    members = chat.get('members', [])
                    names = [m.get('displayName', 'Unknown') for m in members]
                    topic = ", ".join(names)

                topic = (topic or "No Topic")[:38]
                chat_type = chat.get('chatType', '')[:13]
                updated = chat.get('lastUpdatedDateTime', '')[:23]
                print(f"{topic:<40} {chat_type:<15} {updated:<25}")
    except Exception as e:
        print(f"Error: {e}")

@app.command(name="chat-messages", hidden=True)
def chat_messages(
    chat_id: str = typer.Argument(..., help="Chat ID to fetch messages from"),
    top: int = typer.Option(20, "--top", help="Number of messages to fetch (max 50)"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """Fetch message history from a specific chat."""
    try:
        client = GraphClient()
        messages_data = client.get_chat_messages(chat_id)
        messages = messages_data.get('value', [])

        formatted = []
        for msg in messages:
            msg_type = msg.get('messageType', '')
            if msg_type != 'message':
                continue

            from_field = msg.get('from') or {}
            user_field = from_field.get('user') or {}
            sender_name = user_field.get('displayName', 'Unknown')

            body = msg.get('body', {})
            content = body.get('content', '')
            if body.get('contentType') == 'html':
                content = html_to_markdown(content) or content

            formatted.append({
                "sender": sender_name,
                "content": content.strip()[:500] if content else "",
                "timestamp": msg.get('createdDateTime', ''),
                "id": msg.get('id', ''),
            })

        formatted.reverse()
        formatted = formatted[-top:]

        if json_output:
            print(json.dumps(formatted, indent=2))
        else:
            print(f"Chat Messages (last {len(formatted)}):")
            print(f"{'Time':<20} {'From':<20} {'Message':<40}")
            print("-" * 80)

            for msg in formatted:
                timestamp = msg.get('timestamp', '')[:16].replace('T', ' ')
                sender = msg.get('sender', '')[:18]
                preview = msg.get('content', '')[:38]
                if len(msg.get('content', '')) > 38:
                    preview += ".."
                print(f"{timestamp:<20} {sender:<20} {preview:<40}")

    except Exception as e:
        print(f"Error: {e}")


@app.command(hidden=True)
def presence(json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")):
    """Get current user presence."""
    try:
        client = GraphClient()
        p = client.get_presence()

        if json_output:
            print(json.dumps(p, indent=2))
        else:
            availability = p.get('availability', 'Unknown')
            activity = p.get('activity', 'Unknown')
            print(f"Status: {availability} ({activity})")
    except Exception as e:
        print(f"Error: {e}")

@app.command(hidden=True)
def contacts(json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")):
    """List contacts."""
    try:
        client = GraphClient()
        contacts = client.get_contacts()

        if json_output:
            print(json.dumps(contacts.get('value', []), indent=2))
        else:
            print("Contacts:")
            print(f"{'Name':<30} {'Email':<50}")
            print("-" * 80)

            for contact in contacts.get('value', []):
                email = ""
                email_addresses = contact.get('emailAddresses', [])
                if email_addresses:
                    email = email_addresses[0].get('address', '')

                name = contact.get('displayName', 'Unknown')[:28]
                email = email[:48]
                print(f"{name:<30} {email:<50}")
    except Exception as e:
        print(f"Error: {e}")

@app.command(hidden=True)
def teams(json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")):
    """List joined teams."""
    try:
        client = GraphClient()
        teams = client.get_joined_teams()

        if json_output:
            print(json.dumps(teams.get('value', []), indent=2))
        else:
            print("Joined Teams:")
            print(f"{'ID':<40} {'Name':<30}")
            print("-" * 70)

            for team in teams.get('value', []):
                team_id = team.get('id', '')[:38]
                name = team.get('displayName', '')[:28]
                print(f"{team_id:<40} {name:<30}")
    except Exception as e:
        print(f"Error: {e}")

@app.command(hidden=True)
def channels(
    team_id: str = typer.Argument(..., help="Team ID to list channels for"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """List channels in a team."""
    try:
        client = GraphClient()
        channels = client.get_channels(team_id)

        if json_output:
            print(json.dumps(channels.get('value', []), indent=2))
        else:
            print(f"Channels for Team {team_id[:20]}...:")
            print(f"{'ID':<40} {'Name':<30}")
            print("-" * 70)

            for channel in channels.get('value', []):
                ch_id = channel.get('id', '')[:38]
                name = channel.get('displayName', '')[:28]
                print(f"{ch_id:<40} {name:<30}")
    except Exception as e:
        print(f"Error: {e}")

@app.command(hidden=True)
def files(
    folder_id: str = typer.Argument(None, help="Folder ID to list (optional, defaults to root)"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """List files in OneDrive."""
    try:
        client = GraphClient()
        items = client.get_drive_items(folder_id)

        if json_output:
            print(json.dumps(items.get('value', []), indent=2))
        else:
            print("OneDrive Files:")
            print(f"{'Name':<40} {'Type':<10} {'Size':<15}")
            print("-" * 65)

            for item in items.get('value', []):
                name = item.get('name', '')[:38]
                size = f"{item.get('size', 0) / 1024:.1f} KB"

                if 'folder' in item:
                    item_type = "Folder"
                else:
                    item_type = "File"

                print(f"{name:<40} {item_type:<10} {size:<15}")
    except Exception as e:
        print(f"Error: {e}")

from .config import get_email_whitelist_incoming, EMAIL_BLACKLIST
from .security import is_whitelisted, is_blacklisted, verify_email_auth

from .config import REACTION_PROCESSING, REACTION_DONE, REACTION_ERROR

@app.command(name="poll-inbox", hidden=True)
def poll_inbox(
    count: int = typer.Option(10, help="Max number of emails to show (default 10)"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data"),
    hours: int = typer.Option(0, help="Filter by last N hours"),
    minutes: int = typer.Option(0, help="Filter by last N minutes"),
    include_read: bool = typer.Option(False, "--include-read", help="Include read emails in results"),
    user: str = typer.Option(None, "--user", help="Delegate user email (optional)"),
    all_senders: bool = typer.Option(False, "--all-senders", help="Bypass whitelist and show emails from all senders")
):
    """Poll recent emails (Filtered by Whitelist & Security)."""
    try:
        client = GraphClient()

        is_time_based = (hours > 0 or minutes > 0)

        if is_time_based:
            fetch_count = 100
            cutoff_time = datetime.now(dt_timezone.utc) - timedelta(hours=hours, minutes=minutes)
        else:
            fetch_count = count * 3

        emails = client.get_emails(top=fetch_count, include_attachments=json_output, unread_only=not include_read, user_id=user)

        processed_emails = []

        skipped_whitelist_count = 0
        for email in emails.get('value', []):
            sender_email = email.get('from', {}).get('emailAddress', {}).get('address', '')
            sender_name = email.get('from', {}).get('emailAddress', {}).get('name', 'Unknown')

            received = email.get('receivedDateTime', '')
            if is_time_based and received:
                received_dt = datetime.fromisoformat(received.replace('Z', '+00:00'))
                if received_dt < cutoff_time:
                    continue

            if not all_senders and not is_whitelisted(sender_email, get_email_whitelist_incoming()):
                logger.debug(f"Skipped non-whitelisted sender: {sender_email}")
                skipped_whitelist_count += 1
                continue

            if is_blacklisted(sender_email, EMAIL_BLACKLIST):
                logger.debug(f"Skipped blacklisted sender: {sender_email}")
                continue

            headers = email.get('internetMessageHeaders', [])
            auth_status = verify_email_auth(headers)

            # Configurable authentication filtering - import config at top needed
            from aech_cli_msgraph.config import EMAIL_AUTH_DROP_SPF_FAIL, EMAIL_AUTH_DROP_DKIM_FAIL, EMAIL_AUTH_DROP_DMARC_FAIL

            auth_failures = []
            if EMAIL_AUTH_DROP_SPF_FAIL and auth_status['spf'] == 'fail':
                auth_failures.append('SPF')
            if EMAIL_AUTH_DROP_DKIM_FAIL and auth_status['dkim'] == 'fail':
                auth_failures.append('DKIM')
            if EMAIL_AUTH_DROP_DMARC_FAIL and auth_status['dmarc'] == 'fail':
                auth_failures.append('DMARC')

            if auth_failures:
                logger.warning(f"Dropped email from {sender_email} due to auth failure(s): {', '.join(auth_failures)}")
                continue

            # Log warnings for failures that didn't cause drop
            warnings = []
            if not EMAIL_AUTH_DROP_SPF_FAIL and auth_status['spf'] == 'fail':
                warnings.append(f"SPF={auth_status['spf']}")
            if not EMAIL_AUTH_DROP_DKIM_FAIL and auth_status['dkim'] == 'fail':
                warnings.append(f"DKIM={auth_status['dkim']}")
            if not EMAIL_AUTH_DROP_DMARC_FAIL and auth_status['dmarc'] == 'fail':
                warnings.append(f"DMARC={auth_status['dmarc']}")

            if warnings:
                logger.info(f"Email from {sender_email} has auth warnings: {', '.join(warnings)}")

            auth_badge_text = "UNVERIFIED"
            if auth_status['overall_pass']:
                 auth_badge_text = "VERIFIED"
            elif auth_status['spf'] == 'none' and auth_status['dkim'] == 'none':
                 auth_badge_text = "INTERNAL"

            is_read = email.get('isRead', False)
            status_text = "Read" if is_read else "New"

            has_attachments = email.get('hasAttachments', False)
            subject_display = email.get('subject', 'No Subject')
            if has_attachments:
                subject_display = f"[ATT] {subject_display}"

            conversation_id = email.get('conversationId', '')

            body_content = email.get('body', {}).get('content', '')
            body_md = html_to_markdown(body_content) if body_content else ""
            if not body_md:
                body_md = email.get('bodyPreview', '')

            processed_emails.append({
                "status": status_text,
                "subject": subject_display,
                "sender_name": sender_name,
                "sender_email": sender_email,
                "received": received,
                "auth_badge": auth_badge_text,
                "conversation_id": conversation_id,
                "body_preview": email.get('bodyPreview', ''),
                "body_md": body_md,
                "raw_data": email
            })

            if not is_time_based and len(processed_emails) >= count:
                break

        if json_output:
            raw_list = [item['raw_data'] for item in processed_emails]
            print(json.dumps(raw_list, indent=2))
        else:
            title = f"Inbox (Last {hours}h {minutes}m)" if is_time_based else "Inbox (Filtered)"
            print(f"{title}:")
            print(f"{'Status':<8} {'Subject':<35} {'From':<25} {'Auth':<10}")
            print("-" * 80)

            for item in processed_emails:
                status = item['status'][:6]
                subject = item['subject'][:33]
                sender = item['sender_name'][:23]
                auth = item['auth_badge'][:8]
                print(f"{status:<8} {subject:<35} {sender:<25} {auth:<10}")

            if skipped_whitelist_count > 0:
                print(f"\nSkipped {skipped_whitelist_count} message(s) from non-whitelisted senders.")

    except Exception as e:
        print(f"Error: {e}")

@app.command(name="send-mail", hidden=False)
def send_mail(
    to: str = typer.Argument(..., help="Recipient email address"),
    subject: str = typer.Argument(..., help="Email subject"),
    body: str = typer.Argument(..., help="Email body content (HTML supported)"),
    attachment: list[str] = typer.Option(None, help="Path to attachment file (can be used multiple times)")
):
    """Send an email (supports HTML and Attachments)."""
    try:
        if attachment:
            for path in attachment:
                if not os.path.exists(path):
                    print(f"Error: File '{path}' not found.")
                    raise typer.Exit(code=1)

        client = GraphClient()
        client.send_email(to, subject, body, attachments=attachment)
        print(json.dumps({"status": "success", "to": to, "subject": subject}))
    except Exception as e:
        print(json.dumps({"status": "error", "error": str(e)}))
        raise typer.Exit(code=1)

@app.command(name="search-mail", hidden=True)
def search_mail(
    query: str = typer.Argument(..., help="KQL search query"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """Search emails using KQL (Keyword Query Language)."""
    try:
        client = GraphClient()
        results = client.search_emails(query)

        if json_output:
            print(json.dumps(results.get('value', []), indent=2))
        else:
            print(f"Search Results: '{query}'")
            print(f"{'Subject':<40} {'From':<25} {'Received':<20}")
            print("-" * 85)

            for email in results.get('value', []):
                sender = email.get('from', {}).get('emailAddress', {}).get('name', 'Unknown')[:23]
                received = email.get('receivedDateTime', '')[:18]
                subject = email.get('subject', '')[:38]
                print(f"{subject:<40} {sender:<25} {received:<20}")
    except Exception as e:
        print(f"Error: {e}")

@app.command(name="calendar-events", hidden=True)
def calendar_events(
    calendar: str = typer.Option(None, "--calendar", "-c", help="Calendar name or ID (default: primary calendar)"),
    all_calendars: bool = typer.Option(False, "--all", "-a", help="Get events from ALL calendars (excludes system calendars)"),
):
    """List calendar events: single events and series masters for recurring events.
    Use this to see what events are defined, or to get event IDs for modification/deletion.
    """
    try:
        client = GraphClient()

        if calendar and all_calendars:
            print("Error: Cannot use --calendar and --all together.")
            raise typer.Exit(code=1)

        calendar_id = None
        if calendar:
            calendar_id = client.resolve_calendar_id(calendar)
            if not calendar_id:
                print(f"Calendar '{calendar}' not found.")
                raise typer.Exit(code=1)

        if all_calendars:
            events = client.get_all_calendar_events(exclude_system=True)
        else:
            events_data = client.get_calendar_events(calendar_id=calendar_id)
            events = events_data.get('value', [])

        print(json.dumps(events, indent=2))
    except typer.Exit:
        raise
    except Exception as e:
        print(f"Error: {e}")


@app.command(name="poll-calendar", hidden=True)
def poll_calendar(
    start: str = typer.Option(None, "--start", "-s", help="Start time (YYYY-MM-DDTHH:MM:SS, or with Z for UTC) [default: now]"),
    end: str = typer.Option(None, "--end", "-e", help="End time (YYYY-MM-DDTHH:MM:SS, or with Z for UTC) [default: 7 days from start]"),
    calendar: str = typer.Option(None, "--calendar", "-c", help="Calendar name or ID (default: primary calendar)"),
    all_calendars: bool = typer.Option(False, "--all", "-a", help="Get occurrences from ALL calendars (excludes system calendars)"),
):
    """Internal: Poll calendar events. Supports --all for manager polling."""
    from zoneinfo import ZoneInfo

    try:
        client = GraphClient()

        if calendar and all_calendars:
            print("Error: Cannot use --calendar and --all together.")
            raise typer.Exit(code=1)

        calendar_id = None
        if calendar:
            calendar_id = client.resolve_calendar_id(calendar)
            if not calendar_id:
                print(f"Calendar '{calendar}' not found.")
                raise typer.Exit(code=1)

        # Apply defaults for start/end
        # Determine timezone format based on user input (Z suffix = UTC, otherwise user's mailbox timezone)
        if start is None and end is None:
            # No times specified - use user's timezone
            try:
                tz_data = client.get_timezone()
                user_tz = ZoneInfo(tz_data['iana'])
                now = datetime.now(dt_timezone.utc).astimezone(user_tz)
                start = now.strftime("%Y-%m-%dT%H:%M:%S")
                end = (now + timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%S")
            except Exception:
                # Fallback to UTC
                now = datetime.now(dt_timezone.utc)
                start = now.strftime("%Y-%m-%dT%H:%M:%SZ")
                end = (now + timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%SZ")
        elif start is None:
            # End specified, default start to now in same timezone format
            if end.endswith('Z'):
                start = datetime.now(dt_timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            else:
                try:
                    tz_data = client.get_timezone()
                    user_tz = ZoneInfo(tz_data['iana'])
                    start = datetime.now(dt_timezone.utc).astimezone(user_tz).strftime("%Y-%m-%dT%H:%M:%S")
                except Exception:
                    start = datetime.now(dt_timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        elif end is None:
            # Start specified, default end to 7 days later in same timezone format
            if start.endswith('Z'):
                # Parse start and add 7 days
                start_dt = datetime.fromisoformat(start.rstrip('Z')).replace(tzinfo=dt_timezone.utc)
                end = (start_dt + timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%SZ")
            else:
                start_dt = datetime.fromisoformat(start)
                end = (start_dt + timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%S")

        if all_calendars:
            events = client.get_all_calendar_events(
                start_dt=start,
                end_dt=end,
                exclude_system=True,
                complete_view=True
            )
        else:
            events_data = client.get_complete_calendar_view(start, end, calendar_id=calendar_id)
            events = events_data.get('value', [])

        print(json.dumps(events, indent=2))
    except typer.Exit:
        raise
    except Exception as e:
        print(f"Error: {e}")


@app.command(name="calendar-view", hidden=True)
def calendar_view(
    calendar: str = typer.Argument(..., help="Calendar name or ID (required)"),
    start: str = typer.Option(None, "--start", "-s", help="Start time (YYYY-MM-DDTHH:MM:SS, or with Z for UTC) [default: now]"),
    end: str = typer.Option(None, "--end", "-e", help="End time (YYYY-MM-DDTHH:MM:SS, or with Z for UTC) [default: 7 days from start]"),
):
    """View calendar events in a time range, expanding recurring events into instances."""
    from zoneinfo import ZoneInfo

    try:
        client = GraphClient()

        calendar_id = client.resolve_calendar_id(calendar)
        if not calendar_id:
            print(f"Calendar '{calendar}' not found.")
            raise typer.Exit(code=1)

        # Apply defaults for start/end
        if start is None and end is None:
            try:
                tz_data = client.get_timezone()
                user_tz = ZoneInfo(tz_data['iana'])
                now = datetime.now(dt_timezone.utc).astimezone(user_tz)
                start = now.strftime("%Y-%m-%dT%H:%M:%S")
                end = (now + timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%S")
            except Exception:
                now = datetime.now(dt_timezone.utc)
                start = now.strftime("%Y-%m-%dT%H:%M:%SZ")
                end = (now + timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%SZ")
        elif start is None:
            if end.endswith('Z'):
                start = datetime.now(dt_timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
            else:
                try:
                    tz_data = client.get_timezone()
                    user_tz = ZoneInfo(tz_data['iana'])
                    start = datetime.now(dt_timezone.utc).astimezone(user_tz).strftime("%Y-%m-%dT%H:%M:%S")
                except Exception:
                    start = datetime.now(dt_timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        elif end is None:
            if start.endswith('Z'):
                start_dt = datetime.fromisoformat(start.rstrip('Z')).replace(tzinfo=dt_timezone.utc)
                end = (start_dt + timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%SZ")
            else:
                start_dt = datetime.fromisoformat(start)
                end = (start_dt + timedelta(days=7)).strftime("%Y-%m-%dT%H:%M:%S")

        events_data = client.get_complete_calendar_view(start, end, calendar_id=calendar_id)
        events = events_data.get('value', [])

        print(json.dumps(events, indent=2))
    except typer.Exit:
        raise
    except Exception as e:
        print(f"Error: {e}")


@app.command(name="list-calendars", hidden=True)
def list_calendars(
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """List all calendars (default calendar and any additional calendars)."""
    try:
        client = GraphClient()
        calendars = client.list_calendars()

        if json_output:
            print(json.dumps(calendars.get('value', []), indent=2))
        else:
            print("Calendars:")
            print(f"{'Name':<30} {'Default':<10} {'Can Edit':<10} {'ID':<25}")
            print("-" * 75)

            for cal in calendars.get('value', []):
                is_default = "Yes" if cal.get('isDefaultCalendar') else ""
                can_edit = "Yes" if cal.get('canEdit', True) else ""
                cal_id = cal.get('id', '')
                short_id = f"{cal_id[:22]}..." if len(cal_id) > 22 else cal_id
                name = cal.get('name', 'Unknown')[:28]
                print(f"{name:<30} {is_default:<10} {can_edit:<10} {short_id:<25}")
    except Exception as e:
        print(f"Error: {e}")

@app.command(name="create-calendar", hidden=True)
def create_calendar(
    name: str = typer.Argument(..., help="Name for the new calendar"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """Create a new calendar."""
    try:
        client = GraphClient()
        result = client.create_calendar(name)

        if json_output:
            print(json.dumps(result, indent=2))
        else:
            print(f"Calendar '{name}' created successfully!")
            print(f"ID: {result.get('id', 'Unknown')}")
    except Exception as e:
        print(f"Error: {e}")

@app.command(name="delete-calendar", hidden=True)
def delete_calendar_cmd(
    calendar: str = typer.Argument(..., help="Calendar name or ID to delete")
):
    """Delete a calendar by name or ID."""
    try:
        client = GraphClient()

        calendar_id = client.resolve_calendar_id(calendar)
        if not calendar_id:
            print(f"Calendar '{calendar}' not found.")
            raise typer.Exit(code=1)

        client.delete_calendar(calendar_id)
        print("Calendar deleted successfully!")
    except typer.Exit:
        raise
    except Exception as e:
        print(f"Error: {e}")

@app.command(name="add-event", hidden=True)
def add_event(
    calendar: str = typer.Argument(..., help="Calendar name or ID (required)"),
    subject: str = typer.Argument(..., help="Event subject/title"),
    start: str = typer.Argument(..., help="Start time (YYYY-MM-DDTHH:MM:SS)"),
    end: str = typer.Argument(..., help="End time (YYYY-MM-DDTHH:MM:SS)"),
    body: str = typer.Option("", "--body", "-b", help="Event body content"),
    rrule: str = typer.Option(None, "--rrule", "-r", help="RFC 5545 RRULE recurrence pattern"),
    timezone: str = typer.Option(None, "--timezone", "-tz", help="Timezone for start/end (e.g., America/Vancouver). Default: AECH_DEFAULT_TIMEZONE or UTC")
):
    """Create a calendar event"""
    try:
        client = GraphClient()

        if rrule and "FREQ=" not in rrule.upper():
            print("Invalid RRULE: must contain FREQ= component")
            print('Example: --rrule "FREQ=DAILY" or --rrule "FREQ=WEEKLY;BYDAY=MO,WE,FR"')
            raise typer.Exit(code=1)

        calendar_id = client.resolve_calendar_id(calendar)
        if not calendar_id:
            print(f"Calendar '{calendar}' not found.")
            raise typer.Exit(code=1)

        result = client.create_calendar_event(
            subject, start, end,
            content=body,
            calendar_id=calendar_id,
            recurrence=rrule,
            timezone=timezone
        )

        event_id = result.get('id', 'Unknown')
        msg = f"Event created (id: {event_id})"
        if rrule:
            msg += f" (rrule: {rrule})"
        msg += f" in calendar '{calendar}'!"
        print(msg)
    except typer.Exit:
        raise
    except Exception as e:
        print(f"Error: {e}")

@app.command(name="delete-event", hidden=True)
def delete_event(
    event_id: str = typer.Argument(..., help="Event ID to delete")
):
    """Delete a calendar event by ID."""
    try:
        client = GraphClient()
        client.delete_calendar_event(event_id)
        print("Event deleted successfully!")
    except Exception as e:
        print(f"Error: {e}")

@app.command(name="reschedule-event", hidden=True)
def reschedule(
    event_id: str = typer.Argument(..., help="Event ID to reschedule"),
    start: str = typer.Argument(..., help="New start time (YYYY-MM-DDTHH:MM:SS)"),
    end: str = typer.Argument(..., help="New end time (YYYY-MM-DDTHH:MM:SS)"),
    rrule: str = typer.Option(None, "--rrule", "-r", help="New RFC 5545 RRULE pattern, or 'none' to remove recurrence"),
    timezone: str = typer.Option(None, "--timezone", "-tz", help="Timezone for start/end (e.g., America/Vancouver). Default: AECH_DEFAULT_TIMEZONE or UTC")
):
    """Reschedule a calendar event."""
    try:
        client = GraphClient()

        if rrule and rrule.lower() != "none" and "FREQ=" not in rrule.upper():
            print("Invalid RRULE: must contain FREQ= component")
            print('Example: --rrule "FREQ=DAILY" or --rrule "none" to remove recurrence')
            raise typer.Exit(code=1)

        client.update_event(event_id, start=start, end=end, recurrence=rrule, timezone=timezone)

        msg = "Event rescheduled"
        if rrule:
            if rrule.lower() == "none":
                msg += " (recurrence removed)"
            else:
                msg += f" (rrule: {rrule})"
        msg += "!"
        print(msg)
    except typer.Exit:
        raise
    except Exception as e:
        print(f"Error: {e}")

@app.command(name="find-meeting", hidden=True)
def find_meeting(
    emails: str = typer.Argument(..., help="Comma-separated list of attendee emails"),
    duration: int = typer.Option(30, help="Duration in minutes"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """Find meeting times for attendees."""
    try:
        client = GraphClient()
        attendee_list = [e.strip() for e in emails.split(',')]
        result = client.find_meeting_times(attendee_list, duration)

        if json_output:
            print(json.dumps(result, indent=2))
        else:
            candidates = result.get('meetingTimeSuggestions', [])
            if not candidates:
                print("No meeting times found.")
                return

            print("Suggested Meeting Times:")
            print(f"{'Start':<20} {'End':<20} {'Confidence':<10}")
            print("-" * 50)

            for slot in candidates:
                start = slot.get('meetingTimeSlot', {}).get('start', {}).get('dateTime', '')
                end = slot.get('meetingTimeSlot', {}).get('end', {}).get('dateTime', '')
                confidence = slot.get('confidence', 'Unknown')

                start = start.replace('T', ' ')[:16]
                end = end.replace('T', ' ')[:16]

                print(f"{start:<20} {end:<20} {confidence}%")
    except Exception as e:
        print(f"Error: {e}")


@app.command(name="set-presence", hidden=True)
def set_presence(
    status: str = typer.Argument(..., help="Presence status: Available, Busy, DoNotDisturb, BeRightBack, Away, Offline")
):
    """Set presence. Options: Available, Busy, DoNotDisturb, BeRightBack, Away, Offline"""
    try:
        client = GraphClient()
        client.set_presence(status, status)
        print(f"Presence set to {status}")
    except Exception as e:
        print(f"Error: {e}")


@app.command(name="refresh-activity", hidden=True)
def refresh_activity():
    """Refresh Teams activity indicator and set status to Available/Online."""
    from .config import SCOPES, CLIENT_ID

    EXPIRY_MINUTES = 5

    fresh_auth = AuthManager()
    accounts = fresh_auth.app.get_accounts()
    if not accounts:
        print("Not authenticated. Run 'login' first.")
        return

    class MSALCredential:
        def get_token(self, *scopes, **kwargs):
            result = fresh_auth.app.acquire_token_silent(SCOPES, account=accounts[0], force_refresh=True)
            if result and "access_token" in result:
                return AccessToken(result["access_token"], int(time_module.time()) + result.get("expires_in", 3600))
            raise Exception("Failed to get token")

    client = GraphServiceClient(credentials=MSALCredential(), scopes=SCOPES)

    async def refresh():
        user = await client.me.get()
        await client.me.presence.set_presence.post(SetPresencePostRequestBody(
            session_id=CLIENT_ID, availability="Available", activity="Available", expiration_duration=f"PT{EXPIRY_MINUTES}M"
        ))
        await client.me.presence.set_status_message.post(SetStatusMessagePostRequestBody(
            status_message=PresenceStatusMessage(
                message=ItemBody(content_type=BodyType.Text, content="Online"),
                expiry_date_time=DateTimeTimeZone(
                    date_time=(datetime.now(dt_timezone.utc) + timedelta(minutes=EXPIRY_MINUTES)).isoformat(),
                    time_zone="UTC"
                )
            )
        ))
        print(f"Activity refreshed for {user.display_name}")

    try:
        asyncio.run(refresh())
    except Exception as e:
        print(f"Error: {e}")


DEFAULT_TEAMS_SECONDS = 300

@app.command(name="poll-teams", hidden=True)
def poll_teams(
    hours: int = typer.Option(0, help="Fetch messages from the last N hours"),
    minutes: int = typer.Option(0, help="Fetch messages from the last N minutes"),
    seconds: int = typer.Option(DEFAULT_TEAMS_SECONDS, help=f"Fetch messages from the last N seconds (default {DEFAULT_TEAMS_SECONDS})"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data"),
    include_seen: bool | None = typer.Option(None, "--include-seen/--no-include-seen", help="Include messages already seen in previous polls"),
    reset_cache: bool = typer.Option(False, "--reset-cache", help="Clear the Teams message cache before polling"),
    dedupe_cache: bool = typer.Option(False, "--dedupe-cache/--no-dedupe-cache", help="Deduplicate with local cache."),
    include_channels: bool = typer.Option(False, "--include-channels/--no-include-channels", help="Include Teams channel messages"),
    incremental: bool = typer.Option(False, "--incremental/--no-incremental", help="Use incremental sync")
):
    """Poll Teams chats for recent messages. Channels disabled by default."""
    try:
        from .teams_cache import TeamsMessageCache
        from .config import TEAMS_CACHE_FILE, TEAMS_CACHE_EXPIRY_DAYS, debug_log
        from .graph import reset_api_stats, get_api_stats

        reset_api_stats()
        debug_log(f"poll-teams starting: hours={hours}, minutes={minutes}, seconds={seconds}, include_channels={include_channels}, incremental={incremental}")

        client = GraphClient()
        use_cache = dedupe_cache or incremental
        cache = TeamsMessageCache(TEAMS_CACHE_FILE, TEAMS_CACHE_EXPIRY_DAYS) if use_cache else None
        all_messages = []
        new_message_ids = []

        if reset_cache and cache:
            cache.reset()

        cutoff_time = datetime.now(dt_timezone.utc) - timedelta(hours=hours, minutes=minutes, seconds=seconds)

        incremental_since = None
        if incremental and cache:
            last_poll = cache.get_last_poll_time()
            if last_poll:
                try:
                    last_poll_dt = datetime.fromisoformat(last_poll.replace('Z', '+00:00'))
                    incremental_since = (last_poll_dt - timedelta(seconds=60)).isoformat().replace('+00:00', 'Z')
                    debug_log(f"Incremental sync enabled: fetching messages since {incremental_since}")
                except Exception as e:
                    debug_log(f"Failed to parse last_poll time, falling back to full fetch: {e}")
            else:
                debug_log("No previous poll time found, performing full fetch")

        time_window_requested = (hours > 0) or (minutes > 0) or (seconds != DEFAULT_TEAMS_SECONDS)
        use_include_seen = False
        if dedupe_cache:
            use_include_seen = include_seen if include_seen is not None else time_window_requested

        # 1. Poll Chats
        skipped_whitelist_count = 0
        debug_log("Fetching recent chats...")
        chats = client.get_recent_chats()
        chats_list = chats.get('value', [])
        debug_log(f"Found {len(chats_list)} chats")
        for chat in chats_list:
            read_cutoff = chat.get('viewpoint', {}).get('lastMessageReadDateTime')
            read_cutoff_dt = datetime.min.replace(tzinfo=dt_timezone.utc)
            if read_cutoff:
                try:
                    read_cutoff_dt = datetime.fromisoformat(read_cutoff.replace('Z', '+00:00'))
                except Exception:
                    read_cutoff_dt = datetime.min.replace(tzinfo=dt_timezone.utc)

            chat_id = chat.get('id')
            member_lookup = {}
            for m in chat.get('members', []):
                uid = m.get('userId') or m.get('id')
                email = m.get('email')
                dname = m.get('displayName')
                if uid:
                    member_lookup[uid] = {"email": email, "displayName": dname}

            messages = client.get_chat_messages(chat_id, since=incremental_since)
            for msg in messages.get('value', []):
                created = msg.get('createdDateTime')
                message_id = msg.get('id')

                if created and message_id:
                    created_dt = datetime.fromisoformat(created.replace('Z', '+00:00'))
                    effective_cutoff = max(cutoff_time, read_cutoff_dt)
                    if created_dt > effective_cutoff:
                        if dedupe_cache and (not use_include_seen) and cache.is_seen(message_id):
                            continue

                        from_field = msg.get('from') or {}
                        user_field = from_field.get('user') or {}
                        sender_name = user_field.get('displayName', '')
                        sender_email = user_field.get('userPrincipalName', '') or user_field.get('email', '')
                        sender_id = user_field.get('id', '')

                        if sender_id and sender_id in member_lookup:
                            member_info = member_lookup[sender_id]
                            if not sender_email:
                                sender_email = member_info.get('email', '') or sender_email
                            if not sender_name or sender_name == 'Unknown':
                                sender_name = member_info.get('displayName', '') or sender_name
                        sender_identifier = sender_email or sender_id

                        if not sender_name or sender_name == 'Unknown' or not sender_identifier:
                            continue

                        if sender_email and not is_whitelisted(sender_email, get_email_whitelist_incoming()):
                            skipped_whitelist_count += 1
                            continue

                        topic = chat.get('topic')
                        chat_type = chat.get('chatType')
                        if not topic:
                            members = chat.get('members', [])
                            names = []
                            for m in members:
                                dname = m.get('displayName')
                                if dname:
                                    names.append(dname)
                            topic = ", ".join(names) if names else "No Topic"

                        msg['_sourceType'] = 'Chat'
                        msg['_chatId'] = chat_id
                        msg['_chatTopic'] = topic
                        msg['_senderIdentifier'] = sender_identifier
                        all_messages.append(msg)
                        new_message_ids.append((message_id, created))

        # 2. Poll Teams Channels (only if --include-channels)
        if include_channels:
            debug_log("Fetching joined teams for channel polling...")
            teams = client.get_joined_teams()
            channel_jobs = []
            headers = client._get_headers()
            teams_list = teams.get('value', [])
            debug_log(f"Found {len(teams_list)} teams")
            for team in teams_list:
                team_id = team.get('id')
                team_name = team.get('displayName')
                debug_log(f"Fetching channels for team: {team_name}")
                channels = client.get_channels(team_id)
                channels_list = channels.get('value', [])
                debug_log(f"Found {len(channels_list)} channels in {team_name}")
                for channel in channels_list:
                    channel_id = channel.get('id')
                    channel_name = channel.get('displayName')
                    channel_jobs.append((team_id, team_name, channel_id, channel_name))

            debug_log(f"Total channel jobs to fetch messages: {len(channel_jobs)}")

            def fetch_channel_msgs(team_id, team_name, channel_id, channel_name):
                try:
                    resp = requests.get(
                        f"{client.base_url}/teams/{team_id}/channels/{channel_id}/messages",
                        headers=headers,
                        params={"$top": 50},
                        timeout=10,
                    )
                    resp.raise_for_status()
                    return team_id, team_name, channel_id, channel_name, resp.json()
                except Exception as e:
                    debug_log(f"Failed to fetch messages for {team_name}/{channel_name}: {e}")
                    return None

            if channel_jobs:
                with ThreadPoolExecutor(max_workers=4) as pool:
                    futures = [pool.submit(fetch_channel_msgs, *job) for job in channel_jobs]
                    for fut in as_completed(futures):
                        result = fut.result()
                        if not result:
                            continue
                        team_id, team_name, channel_id, channel_name, payload = result
                        for msg in payload.get('value', []):
                            created = msg.get('createdDateTime')
                            message_id = msg.get('id')

                            if created and message_id:
                                created_dt = datetime.fromisoformat(created.replace('Z', '+00:00'))
                                if created_dt > cutoff_time:
                                    if dedupe_cache and (not use_include_seen) and cache.is_seen(message_id):
                                        continue

                                    from_field = msg.get('from') or {}
                                    user_field = from_field.get('user') or {}
                                    sender_name = user_field.get('displayName', '')
                                    sender_email = user_field.get('userPrincipalName', '') or user_field.get('email', '')
                                    sender_id = user_field.get('id', '')
                                    sender_identifier = sender_email or sender_id

                                    if not sender_name or sender_name == 'Unknown' or not sender_identifier:
                                        continue

                                    if sender_email and not is_whitelisted(sender_email, get_email_whitelist_incoming()):
                                        skipped_whitelist_count += 1
                                        continue

                                    msg['_sourceType'] = 'Channel'
                                    msg['_teamId'] = team_id
                                    msg['_teamName'] = team_name
                                    msg['_channelId'] = channel_id
                                    msg['_channelName'] = channel_name
                                    msg['_senderIdentifier'] = sender_identifier
                                    all_messages.append(msg)
                                    new_message_ids.append((message_id, created))
        else:
            debug_log("Skipping channel polling (use --include-channels to enable)")

        if dedupe_cache and new_message_ids:
            cache.mark_batch_seen(new_message_ids)
        elif incremental and cache:
            cache.cache["last_poll"] = datetime.now(dt_timezone.utc).isoformat()
            cache._save_cache()
            debug_log(f"Updated last_poll timestamp for incremental sync")

        stats = get_api_stats()
        debug_log(f"poll-teams complete: {stats['calls']} API calls in {stats['elapsed_ms']}ms, {len(all_messages)} messages returned")

        all_messages.sort(key=lambda x: x.get('createdDateTime', ''), reverse=True)

        # Fetch attachment content for JSON output
        if json_output and all_messages:
            for msg in all_messages:
                inline_images = client.extract_and_fetch_inline_images(msg)
                if inline_images:
                    msg['_inlineImages'] = inline_images
                    debug_log(f"Found {len(inline_images)} inline image(s) in message {msg.get('id')}")

                attachments = msg.get('attachments', [])
                if attachments:
                    enriched_attachments = []
                    for att in attachments:
                        content_type = att.get('contentType', '')
                        if content_type == 'reference' and att.get('contentUrl'):
                            enriched = client.fetch_teams_attachment_content(att)
                            enriched_attachments.append(enriched)
                        else:
                            enriched_attachments.append(att)
                    msg['attachments'] = enriched_attachments

        if json_output:
            print(json.dumps(all_messages, indent=2))
        else:
            time_desc = f"{hours}h {minutes}m {seconds}s" if hours or minutes else f"{seconds}s"
            print(f"Recent Teams Activity (Last {time_desc}):")
            print(f"{'Time':<20} {'Source':<10} {'Context':<25} {'From':<15} {'Preview':<30}")
            print("-" * 100)

            for msg in all_messages:
                created = msg.get('createdDateTime', '')[:16].replace('T', ' ')
                source = msg.get('_sourceType', 'Unknown')[:8]

                if source == 'Channel':
                    context = f"{msg.get('_teamName', '')[:10]}>{msg.get('_channelName', '')[:12]}"
                else:
                    context = msg.get('_chatTopic', '')[:23]

                from_field = msg.get('from') or {}
                user_field = from_field.get('user') or {}
                sender = user_field.get('displayName', 'Unknown')[:13]

                body_field = msg.get('body') or {}
                body = body_field.get('content') or ''

                preview = html_to_markdown(body)
                if not preview:
                    preview = body or ""
                preview = preview.replace('\n', ' ').strip()[:28]

                print(f"{created:<20} {source:<10} {context:<25} {sender:<15} {preview:<30}")

            if skipped_whitelist_count > 0:
                print(f"\nSkipped {skipped_whitelist_count} message(s) from non-whitelisted senders.")

    except Exception as e:
        print(f"Error: {e}")


@app.command(name="react-processing", hidden=True)
def react_processing(
    message_id: str = typer.Argument(..., help="Message ID to react to"),
    source: str = typer.Option("chat", "--source", help="chat or channel"),
    chat_id: str = typer.Option(None, help="Chat ID (required for chat source)"),
    team_id: str = typer.Option(None, help="Team ID (required for channel source)"),
    channel_id: str = typer.Option(None, help="Channel ID (required for channel source)"),
    emoji: str = typer.Option(None, "--emoji", help="Override processing reaction emoji")
):
    """Add a 'processing' reaction to a message (default from env)."""
    try:
        client = GraphClient()
        reaction = emoji or REACTION_PROCESSING
        if source == "chat":
            if not chat_id:
                raise ValueError("chat_id is required for chat source")
            client.set_chat_reaction(chat_id, message_id, reaction)
        elif source == "channel":
            if not (team_id and channel_id):
                raise ValueError("team_id and channel_id are required for channel source")
            client.set_channel_reaction(team_id, channel_id, message_id, reaction)
        else:
            raise ValueError("source must be 'chat' or 'channel'")
        print(f"Added processing reaction ({reaction})")
    except Exception as e:
        print(f"Error: {e}")


@app.command(name="react-done", hidden=True)
def react_done(
    message_id: str = typer.Argument(..., help="Message ID to react to"),
    source: str = typer.Option("chat", "--source", help="chat or channel"),
    chat_id: str = typer.Option(None, help="Chat ID (required for chat source)"),
    team_id: str = typer.Option(None, help="Team ID (required for channel source)"),
    channel_id: str = typer.Option(None, help="Channel ID (required for channel source)"),
    success: bool = typer.Option(True, "--success/--error", help="Mark success or error"),
    clear_processing: bool = typer.Option(True, "--clear-processing/--no-clear-processing", help="Remove processing reaction"),
    emoji: str = typer.Option(None, "--emoji", help="Override done reaction emoji")
):
    """Mark completion on a message."""
    try:
        client = GraphClient()
        done_emoji = emoji or (REACTION_DONE if success else REACTION_ERROR)
        processing_emoji = REACTION_PROCESSING

        if source == "chat":
            if not chat_id:
                raise ValueError("chat_id is required for chat source")
            if clear_processing:
                client.unset_chat_reaction(chat_id, message_id, processing_emoji)
            client.set_chat_reaction(chat_id, message_id, done_emoji)
        elif source == "channel":
            if not (team_id and channel_id):
                raise ValueError("team_id and channel_id are required for channel source")
            if clear_processing:
                client.unset_channel_reaction(team_id, channel_id, message_id, processing_emoji)
            client.set_channel_reaction(team_id, channel_id, message_id, done_emoji)
        else:
            raise ValueError("source must be 'chat' or 'channel'")

        print(f"Added done reaction ({done_emoji})")
    except Exception as e:
        print(f"Error: {e}")

@app.command(name = "reply-mail", hidden=True)
def reply_mail(
    message_id: str = typer.Argument(..., help="Message ID to reply to"),
    content: str = typer.Argument(..., help="Reply content"),
    attachment: list[str] = typer.Option(None, help="Path to attachment file (can be used multiple times)")
):
    """Reply to an email."""
    try:
        if attachment:
            for path in attachment:
                if not os.path.exists(path):
                    print(f"Error: File '{path}' not found.")
                    raise typer.Exit(code=1)

        client = GraphClient()
        client.reply_email(message_id, content, attachments=attachment)
        print("Reply sent successfully!")
    except Exception as e:
        print(f"Error: {e}")



@app.command(hidden=True)
def upload(
    file_path: str = typer.Argument(..., help="Path to file to upload"),
    folder_id: str = typer.Argument(None, help="Target Folder ID (optional)")
):
    """Upload a file to OneDrive."""
    try:
        client = GraphClient()
        if not os.path.exists(file_path):
            print(f"Error: File '{file_path}' not found.")
            return

        result = client.upload_file(file_path, folder_id)
        print(f"Uploaded successfully! ID: {result.get('id')}")
    except Exception as e:
        print(f"Error: {e}")

@app.command(hidden=True)
def download(
    file_id: str = typer.Argument(..., help="OneDrive file ID to download"),
    output_path: str = typer.Argument(None, help="Output path (optional)")
):
    """Download a file from OneDrive by file ID.

    Outputs: output_path (or file_id if not specified)
    """
    try:
        client = GraphClient()

        if not output_path:
            output_path = file_id

        response = client.download_file(file_id)

        with open(output_path, 'wb') as f:
            f.write(response.content)

        print(f"Downloaded to {output_path}")
    except Exception as e:
        print(f"Error: {e}")

@app.command(name="download-url", hidden=True)
def download_url(
    url: str = typer.Argument(..., help="SharePoint/OneDrive URL to download"),
    output_path: str = typer.Argument(None, help="Output path (optional)")
):
    """Download a file from a SharePoint/OneDrive URL.

    Outputs: output_path (or filename from URL if not specified)
    """
    try:
        client = GraphClient()

        content, filename = client.download_file_by_url(url)
        final_path = output_path or filename

        with open(final_path, 'wb') as f:
            f.write(content)

        print(f"Downloaded to {final_path}")
    except Exception as e:
        print(f"Error: {e}")


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".webp"}
IMAGE_MIME_TYPES = {
    ".png": "image/png",
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".gif": "image/gif",
    ".webp": "image/webp",
}


def _process_attachments(client: GraphClient, content: str, attachments: list[str] | None) -> tuple[str, list[dict] | None, list[str]]:
    """Process attachments: embed images inline, upload other files to OneDrive.

    Returns a tuple of (final_content, hosted_contents, errors) where:
    - final_content: message content with image tags and attachment links
    - hosted_contents: list of inline image dicts for Teams hostedContents API (or None)
    - errors: list of error messages for failed attachments
    """
    import base64

    if not attachments:
        return content, None, []

    errors = []

    # Separate images from other files
    images = []
    other_files = []
    for path in attachments:
        basename = os.path.basename(path)
        if not os.path.exists(path):
            errors.append(f"File not found: {path}")
            print(f"Warning: {path} not found, skipping attachment", file=sys.stderr)
            continue

        ext = os.path.splitext(path)[1].lower()
        if ext in IMAGE_EXTENSIONS:
            images.append(path)
        else:
            other_files.append(path)

    # Process images for inline embedding
    hosted_contents = []
    image_html_parts = []
    for i, path in enumerate(images):
        ext = os.path.splitext(path)[1].lower()
        mime_type = IMAGE_MIME_TYPES[ext]
        filename = os.path.basename(path)

        try:
            with open(path, "rb") as f:
                content_bytes = base64.b64encode(f.read()).decode("utf-8")

            hosted_contents.append({
                "contentBytes": content_bytes,
                "contentType": mime_type,
            })
            # Reference the hosted content by its temporary ID (1-indexed)
            image_html_parts.append(
                f'<img src="../hostedContents/{len(hosted_contents)}/$value" alt="{filename}" style="max-width:100%">'
            )
            print(f"Embedding {filename} inline")
        except Exception as e:
            errors.append(f"Failed to read {filename}: {e}")
            print(f"Warning: Failed to read {filename}: {e}", file=sys.stderr)

    # Upload other files to OneDrive
    attachment_links = []
    for path in other_files:
        basename = os.path.basename(path)
        try:
            print(f"Uploading {basename} to OneDrive...")
            filename, share_url = client.upload_and_share(path)
            attachment_links.append((filename, share_url))
            print(f"  Uploaded and shared: {filename}")
        except Exception as e:
            errors.append(f"Failed to upload {basename}: {e}")
            print(f"Warning: Failed to upload {basename}: {e}", file=sys.stderr)

    # Build final content
    final_content = content

    # Add inline images at the end of the message
    if image_html_parts:
        final_content += "\n\n" + "\n".join(image_html_parts)

    # Add OneDrive links for non-image attachments
    if attachment_links:
        final_content += "\n\n**Attachments:**"
        for filename, url in attachment_links:
            final_content += f"\n- [{filename}]({url})"

    return final_content, hosted_contents if hosted_contents else None, errors


@app.command(name="get-or-create-teams-chat", hidden=False)
def get_or_create_teams_chat(
    user_email: str = typer.Argument(..., help="Email address of user to chat with")
):
    """Get or create a 1:1 Teams chat with a user. Returns the chat ID."""
    try:
        client = GraphClient()
        chat = client.get_or_create_chat(user_email)
        chat_id = chat.get("id")
        print(json.dumps({"status": "success", "chat_id": chat_id}))
    except Exception as e:
        print(json.dumps({"status": "error", "error": str(e)}))
        raise typer.Exit(code=1)


@app.command(name="send-teams", hidden=False)
def send_teams(
    chat_id: str = typer.Argument(..., help="Chat ID to send message to"),
    content: str = typer.Argument(..., help="Message content (HTML supported)"),
    attachment: list[str] = typer.Option(None, "--attachment", "-a", help="Path to file attachment")
):
    """Send a message to a Teams chat. Images are embedded inline."""
    try:
        client = GraphClient()
        final_content, hosted_contents, attachment_errors = _process_attachments(client, content, attachment)
        client.send_chat_message(chat_id, final_content, hosted_contents=hosted_contents)
        result: dict[str, Any] = {"status": "success", "chat_id": chat_id}
        if attachment_errors:
            result["attachment_errors"] = attachment_errors
        print(json.dumps(result))
    except Exception as e:
        print(json.dumps({"status": "error", "error": str(e)}))
        raise typer.Exit(code=1)


@app.command(name="send-teams-channel", hidden=True)
def send_teams_channel(
    team_id: str = typer.Argument(..., help="Team ID"),
    channel_id: str = typer.Argument(..., help="Channel ID"),
    content: str = typer.Argument(..., help="Message content (HTML supported)"),
    attachment: list[str] = typer.Option(None, "--attachment", "-a", help="Path to file attachment")
):
    """Send a new message to a Teams channel. Images are embedded inline."""
    try:
        client = GraphClient()
        final_content, hosted_contents, attachment_errors = _process_attachments(client, content, attachment)
        client.send_channel_message(team_id, channel_id, final_content, hosted_contents=hosted_contents)
        if attachment_errors:
            print(f"Message sent (with {len(attachment_errors)} attachment error(s)):", file=sys.stderr)
            for err in attachment_errors:
                print(f"  - {err}", file=sys.stderr)
        else:
            print("Message sent successfully!")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        raise typer.Exit(code=1)


@app.command(name="reply-teams-channel", hidden=True)
def reply_teams_channel(
    team_id: str = typer.Argument(..., help="Team ID"),
    channel_id: str = typer.Argument(..., help="Channel ID"),
    message_id: str = typer.Argument(..., help="Message ID to reply to"),
    content: str = typer.Argument(..., help="Reply content (HTML supported)"),
    attachment: list[str] = typer.Option(None, "--attachment", "-a", help="Path to file attachment")
):
    """Reply to a Teams channel message thread. Images are embedded inline."""
    try:
        client = GraphClient()
        final_content, hosted_contents, attachment_errors = _process_attachments(client, content, attachment)
        client.reply_channel_message(team_id, channel_id, message_id, final_content, hosted_contents=hosted_contents)
        if attachment_errors:
            print(f"Reply sent (with {len(attachment_errors)} attachment error(s)):", file=sys.stderr)
            for err in attachment_errors:
                print(f"  - {err}", file=sys.stderr)
        else:
            print("Reply sent successfully!")
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        raise typer.Exit(code=1)

@app.command(hidden=True)
def attachments(
    message_id: str = typer.Argument(..., help="Email message ID"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """List attachments for an email."""
    try:
        client = GraphClient()
        items = client.get_attachments(message_id)

        if json_output:
            print(json.dumps(items.get('value', []), indent=2))
        else:
            print("Attachments:")
            print(f"{'Name':<40} {'Type':<25} {'Size':<15}")
            print("-" * 80)

            for item in items.get('value', []):
                name = item.get('name', '')[:38]
                content_type = item.get('contentType', 'Unknown')[:23]
                size = f"{item.get('size', 0) / 1024:.1f} KB"
                print(f"{name:<40} {content_type:<25} {size:<15}")
    except Exception as e:
        print(f"Error: {e}")

@app.command(name="download-attachment", hidden=True)
def download_attachment(
    message_id: str = typer.Argument(..., help="Email message ID"),
    attachment_id: str = typer.Argument(..., help="Attachment ID to download"),
    output_path: str = typer.Argument(None, help="Output path (optional)"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data (including base64 content)")
):
    """Download an email attachment.

    Outputs: output_path (or original attachment filename if not specified)
    """
    try:
        client = GraphClient()

        if json_output:
            att = client.get_attachment(message_id, attachment_id)
            print(json.dumps(att, indent=2))
            return

        if not output_path:
             items = client.get_attachments(message_id)
             filename = "attachment.bin"
             for item in items.get('value', []):
                 if item.get('id') == attachment_id:
                     filename = item.get('name')
                     break
             output_path = filename

        response = client.download_attachment(message_id, attachment_id)
        with open(output_path, 'wb') as f:
            f.write(response.content)

        print(f"Downloaded to {output_path}")
    except Exception as e:
        print(f"Error: {e}")

@app.command(name="get-read-status", hidden=True)
def get_read_status(
    message_id: str = typer.Argument(..., help="Email message ID"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """Get the read status of an email."""
    try:
        client = GraphClient()
        result = client.get_email_read_status(message_id)

        if json_output:
            print(json.dumps(result, indent=2))
        else:
            is_read = result.get('isRead')
            status = "Read" if is_read else "Unread"
            print(f"Message Read Status: {status}")
    except Exception as e:
        print(f"Error: {e}")

@app.command(name="set-read-status", hidden=True)
def set_read_status(
    message_id: str = typer.Argument(..., help="Email message ID"),
    is_read: bool = typer.Argument(..., help="Read status (true/false)"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """Set the read status of an email (true/false)."""
    try:
        client = GraphClient()
        result = client.set_email_read_status(message_id, is_read)

        if json_output:
            print(json.dumps(result, indent=2))
        else:
            status = "Read" if is_read else "Unread"
            print(f"Message marked as {status}")
    except Exception as e:
        print(f"Error: {e}")

@app.command(name="mark-read", hidden=True)
def mark_read(
    message_id: str = typer.Argument(..., help="Email message ID"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """Mark an email as read."""
    set_read_status(message_id, True, json_output)

@app.command(name="mark-unread", hidden=True)
def mark_unread(
    message_id: str = typer.Argument(..., help="Email message ID"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """Mark an email as unread."""
    set_read_status(message_id, False, json_output)

@app.command(name="move-email", hidden=True)
def move_email(
    message_id: str = typer.Argument(..., help="Email message ID"),
    folder_name: str = typer.Argument(..., help="Target folder name"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data"),
    user: str = typer.Option(None, "--user", help="Delegate user email (optional)")
):
    """Move an email to a specific folder by name."""
    try:
        client = GraphClient()

        folders = client.get_mail_folders(user_id=user)
        target_id = None
        target_name_lower = folder_name.lower()

        for folder in folders.get("value", []):
            if folder.get("displayName", "").lower() == target_name_lower:
                target_id = folder.get("id")
                break

        if not target_id:
            msg = f"Folder '{folder_name}' not found."
            if json_output:
                print(json.dumps({"error": msg}, indent=2))
            else:
                print(msg)
            raise typer.Exit(code=1)

        result = client.move_message(message_id, target_id, user_id=user)

        if json_output:
            print(json.dumps(result, indent=2))
        else:
            print(f"Message moved to '{folder_name}'")

    except Exception as e:
        if json_output:
            print(json.dumps({"error": str(e)}, indent=2))
        else:
            print(f"Error: {e}")
        raise typer.Exit(code=1)

@app.command(name="delete-email", hidden=True)
def delete_email(
    message_id: str = typer.Argument(..., help="Email message ID to delete"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data"),
    user: str = typer.Option(None, "--user", help="Delegate user email (optional)")
):
    """Delete an email."""
    try:
        client = GraphClient()
        client.delete_message(message_id, user_id=user)

        if json_output:
            print(json.dumps({"status": "success", "messageId": message_id}, indent=2))
        else:
            print("Message deleted successfully")
    except Exception as e:
        if json_output:
            print(json.dumps({"error": str(e)}, indent=2))
        else:
            print(f"Error: {e}")
        raise typer.Exit(code=1)


# =============================================================================
# Message Categories & Flags
# =============================================================================

@app.command(name="update-message", hidden=True)
def update_message_cmd(
    message_id: str = typer.Argument(..., help="Email message ID to update"),
    categories: str = typer.Option(None, "--categories", help="Set categories (comma-separated): 'Work,Action Required'"),
    add_category: str = typer.Option(None, "--add-category", help="Add a category without replacing existing"),
    remove_category: str = typer.Option(None, "--remove-category", help="Remove a specific category"),
    clear_categories: bool = typer.Option(False, "--clear-categories", help="Remove all categories"),
    flag: str = typer.Option(None, "--flag", help="Set flag status: flagged, complete, notFlagged"),
    flag_due: str = typer.Option(None, "--flag-due", help="Due date: ISO-8601 or relative (today, tomorrow, this-week, next-week)"),
    importance: str = typer.Option(None, "--importance", help="Set importance: low, normal, high"),
    is_read: bool = typer.Option(None, "--is-read/--is-unread", help="Mark as read or unread"),
    user: str = typer.Option(None, "--user", help="Delegate user email (shared mailbox)"),
):
    """Update message properties: categories, flags, importance, read status."""
    try:
        client = GraphClient()

        # Validate mutually exclusive category options
        category_options_set = sum([
            categories is not None,
            add_category is not None,
            remove_category is not None,
            clear_categories
        ])
        if category_options_set > 1:
            msg = "Cannot use multiple category options together. Choose one of: --categories, --add-category, --remove-category, --clear-categories"
            print(json.dumps({"error": msg}, indent=2))
            raise typer.Exit(code=1)

        # Validate flag value
        if flag and flag.lower() not in ("flagged", "complete", "notflagged"):
            msg = f"Invalid flag value: '{flag}'. Use: flagged, complete, or notFlagged"
            print(json.dumps({"error": msg}, indent=2))
            raise typer.Exit(code=1)

        # Validate importance value
        if importance and importance.lower() not in ("low", "normal", "high"):
            msg = f"Invalid importance value: '{importance}'. Use: low, normal, or high"
            print(json.dumps({"error": msg}, indent=2))
            raise typer.Exit(code=1)

        # Resolve categories
        final_categories = None
        if clear_categories:
            final_categories = []
        elif categories:
            final_categories = [c.strip() for c in categories.split(",") if c.strip()]
        elif add_category or remove_category:
            # Need to fetch current message to get existing categories
            msg_data = client.get_message(message_id, user_id=user, select="categories")
            current_categories = msg_data.get("categories", [])

            if add_category:
                if add_category not in current_categories:
                    final_categories = current_categories + [add_category]
                else:
                    final_categories = current_categories  # Already has it
            elif remove_category:
                if remove_category in current_categories:
                    final_categories = [c for c in current_categories if c != remove_category]
                else:
                    final_categories = current_categories  # Didn't have it

        # Resolve flag dates
        flag_start = None
        flag_due_resolved = None
        if flag_due:
            tz_data = client.get_timezone()
            flag_start, flag_due_resolved = resolve_flag_due(flag_due, tz_data["iana"])

        # Normalize flag status casing
        flag_status = flag.lower() if flag else None
        if flag_status == "notflagged":
            flag_status = "notFlagged"  # Graph API expects this exact casing

        # Call update
        result = client.update_message_properties(
            message_id=message_id,
            categories=final_categories,
            flag_status=flag_status,
            flag_start_datetime=flag_start,
            flag_due_datetime=flag_due_resolved,
            importance=importance.lower() if importance else None,
            is_read=is_read,
            user_id=user,
        )

        print(json.dumps(result, indent=2))

    except typer.Exit:
        raise
    except Exception as e:
        print(json.dumps({"error": str(e)}, indent=2))
        raise typer.Exit(code=1)


@app.command(name="list-categories", hidden=True)
def list_categories(
    user: str = typer.Option(None, "--user", help="Delegate user email (shared mailbox)"),
):
    """List master categories with colors."""
    try:
        client = GraphClient()
        result = client.get_master_categories(user_id=user)
        print(json.dumps(result.get("value", []), indent=2))

    except Exception as e:
        print(json.dumps({"error": str(e)}, indent=2))
        raise typer.Exit(code=1)


@app.command(name="create-category", hidden=True)
def create_category(
    name: str = typer.Argument(..., help="Category name"),
    color: str = typer.Option("blue", "--color", "-c", help="Color: preset0-preset24 or name (red, blue, green, etc.)"),
    user: str = typer.Option(None, "--user", help="Delegate user email (shared mailbox)"),
):
    """Create a master category with a specified color."""
    try:
        client = GraphClient()
        result = client.create_master_category(name, color, user_id=user)
        print(json.dumps(result, indent=2))

    except Exception as e:
        print(json.dumps({"error": str(e)}, indent=2))
        raise typer.Exit(code=1)


@app.command(name="delete-category", hidden=True)
def delete_category(
    category: str = typer.Argument(..., help="Category name or ID to delete"),
    user: str = typer.Option(None, "--user", help="Delegate user email (shared mailbox)"),
):
    """Delete a master category by name or ID."""
    try:
        client = GraphClient()

        # Resolve name to ID if needed
        category_id = client.resolve_category_id(category, user_id=user)
        if not category_id:
            msg = f"Category '{category}' not found"
            print(json.dumps({"error": msg}, indent=2))
            raise typer.Exit(code=1)

        client.delete_master_category(category_id, user_id=user)
        print(json.dumps({"status": "success", "category": category}, indent=2))

    except typer.Exit:
        raise
    except Exception as e:
        print(json.dumps({"error": str(e)}, indent=2))
        raise typer.Exit(code=1)


@app.command(name="list-folders", hidden=True)
def list_folders(
    user: str = typer.Option(None, "--user", help="Delegate user email (optional)"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """List all mail folders in the mailbox."""
    try:
        client = GraphClient()
        folders = client.get_mail_folders(user_id=user)

        if json_output:
            print(json.dumps(folders.get('value', []), indent=2))
        else:
            print("Mail Folders:")
            print(f"{'Display Name':<25} {'Total':<10} {'Unread':<10} {'Folder ID':<25}")
            print("-" * 70)

            for folder in folders.get('value', []):
                name = folder.get('displayName', 'Unknown')[:23]
                total = str(folder.get('totalItemCount', 0))
                unread = str(folder.get('unreadItemCount', 0))
                folder_id = folder.get('id', '')[:22] + '...'
                print(f"{name:<25} {total:<10} {unread:<10} {folder_id:<25}")
    except Exception as e:
        if json_output:
            print(json.dumps({"error": str(e)}, indent=2))
        else:
            print(f"Error: {e}")
        raise typer.Exit(code=1)

@app.command(name="list-messages", hidden=True)
def list_messages(
    folder: str = typer.Option(..., "--folder", help="Folder name to list messages from"),
    user: str = typer.Option(None, "--user", help="Delegate user email (optional)"),
    count: int = typer.Option(50, "--count", help="Maximum number of messages to return"),
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """List messages from a specific folder."""
    try:
        client = GraphClient()

        folders = client.get_mail_folders(user_id=user)
        target_id = None
        target_name_lower = folder.lower()

        for f in folders.get("value", []):
            if f.get("displayName", "").lower() == target_name_lower:
                target_id = f.get("id")
                break

        if not target_id:
            msg = f"Folder '{folder}' not found."
            if json_output:
                print(json.dumps({"error": msg}, indent=2))
            else:
                print(msg)
            raise typer.Exit(code=1)

        messages = client.get_folder_messages(
            folder_id=target_id,
            top=count,
            include_attachments=json_output,
            user_id=user
        )

        if json_output:
            print(json.dumps(messages.get('value', []), indent=2))
        else:
            print(f"Messages in '{folder}' (showing {len(messages.get('value', []))}):")
            print(f"{'Subject':<35} {'From':<25} {'Received':<18} {'Read':<6}")
            print("-" * 85)

            for msg in messages.get('value', []):
                sender = msg.get('from', {}).get('emailAddress', {})
                sender_name = sender.get('name', 'Unknown')[:23]

                received = msg.get('receivedDateTime', '')[:16].replace('T', ' ')
                is_read = "Yes" if msg.get('isRead', False) else "No"

                has_attachments = msg.get('hasAttachments', False)
                subject_display = msg.get('subject', 'No Subject')[:33]
                if has_attachments:
                    subject_display = f"[A] {subject_display}"[:33]

                print(f"{subject_display:<35} {sender_name:<25} {received:<18} {is_read:<6}")
    except Exception as e:
        if json_output:
            print(json.dumps({"error": str(e)}, indent=2))
        else:
            print(f"Error: {e}")
        raise typer.Exit(code=1)


@app.command(name="get-scopes", hidden=True)
def get_scopes(
    json_output: bool = typer.Option(False, "--json", help="Output raw JSON data")
):
    """Get the list of permissions (scopes) granted to the current session."""
    try:
        auth = AuthManager()
        token_result = auth.get_token()

        scopes = []
        if token_result and "access_token" in token_result:
            access_token = token_result["access_token"]
            try:
                parts = access_token.split('.')
                if len(parts) >= 2:
                    payload_b64 = parts[1]
                    padding = len(payload_b64) % 4
                    if padding:
                        payload_b64 += '=' * (4 - padding)

                    import base64
                    payload_bytes = base64.urlsafe_b64decode(payload_b64)
                    payload = json.loads(payload_bytes)

                    scp = payload.get("scp", "")
                    if isinstance(scp, str):
                        scopes = scp.split()
                    elif isinstance(scp, list):
                        scopes = scp
            except Exception:
                pass

        result = {"value": scopes}

        if json_output:
            print(json.dumps(result, indent=2))
        else:
            if scopes:
                print("Granted Scopes:")
                for scope in scopes:
                    print(f"- {scope}")
            else:
                print("No scopes found or not logged in.")

    except Exception as e:
        if json_output:
            print(json.dumps({"value": []}, indent=2))
        else:
            print(f"Error: {e}")

def run() -> None:
    """CLI entry point."""
    app()


if __name__ == "__main__":
    run()
