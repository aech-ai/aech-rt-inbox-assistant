import requests
import os
import time
import json
from .auth import AuthManager
from .pandoc_utils import markdown_to_html
from .config import debug_log, get_email_whitelist_outgoing
from .security import check_outbound_allowed

# Track API call statistics per session
_api_call_count = 0
_api_call_start_time = None

def get_api_stats():
    """Return API call statistics."""
    global _api_call_count, _api_call_start_time
    if _api_call_start_time is None:
        return {"calls": 0, "elapsed_ms": 0}
    elapsed = (time.time() - _api_call_start_time) * 1000
    return {"calls": _api_call_count, "elapsed_ms": int(elapsed)}

def reset_api_stats():
    """Reset API call statistics."""
    global _api_call_count, _api_call_start_time
    _api_call_count = 0
    _api_call_start_time = time.time()

# Color name to Graph API preset mapping for categories
CATEGORY_COLOR_NAMES = {
    "red": "preset0",
    "orange": "preset1",
    "brown": "preset2",
    "yellow": "preset3",
    "green": "preset4",
    "teal": "preset5",
    "olive": "preset6",
    "blue": "preset7",
    "purple": "preset8",
    "cranberry": "preset9",
    "steel": "preset10",
    "darksteel": "preset11",
    "gray": "preset12",
    "grey": "preset12",  # British spelling alias
    "darkgray": "preset13",
    "black": "preset14",
}

class GraphClient:
    def __init__(self):
        self.auth = AuthManager()
        self.base_url = "https://graph.microsoft.com/v1.0"

    def _get_base_path(self, user_id: str = None) -> str:
        """Get the base path for requests (me or specific user)."""
        if user_id:
            return f"{self.base_url}/users/{user_id}"
        return f"{self.base_url}/me"

    def _track_call(self, method: str, url: str):
        """Track API call for debugging."""
        global _api_call_count, _api_call_start_time
        if _api_call_start_time is None:
            _api_call_start_time = time.time()
        _api_call_count += 1
        # Shorten URL for logging
        short_url = url.replace(self.base_url, "")
        debug_log(f"API #{_api_call_count} {method} {short_url}")

    def _get_json(self, url, *, params=None, extra_headers=None):
        """Perform a GET request and surface Graph errors explicitly."""
        self._track_call("GET", url)
        if params:
            debug_log(f"  params: {params}")
        headers = self._get_headers()
        if extra_headers:
            headers.update(extra_headers)
        response = requests.get(url, headers=headers, params=params)
        if not response.ok:
            try:
                detail = response.json()
            except Exception:
                detail = response.text
            raise Exception(f"Graph GET failed ({response.status_code}) for {url}: {detail}")
        try:
            return response.json()
        except json.JSONDecodeError:
            raise Exception(f"Graph GET returned empty/invalid JSON ({response.status_code}) for {url}: {response.text[:200] if response.text else '(empty)'}")

    def _get_headers(self):
        token_result = self.auth.get_token()
        if not token_result:
            raise Exception("Not authenticated. Please run 'login' command first.")
        return {
            "Authorization": "Bearer " + token_result["access_token"],
            "Content-Type": "application/json"
        }

    def get_me(self):
        return self._get_json(f"{self.base_url}/me")

    def get_teams_messages(self):
        # Note: Getting all messages usually requires iterating chats first.
        # For simplicity, let's get recent chats and their last message.
        # Or we can list joined teams. 
        # Let's implement 'get joined teams' and 'get chats'
        return self._get_json(f"{self.base_url}/me/chats", params={"$expand": "members"})

    def get_calendar_events(self, calendar_id=None):
        """Get events from a calendar.

        Args:
            calendar_id: Optional calendar ID. If None, uses the default calendar.
        """
        if calendar_id:
            return self._get_json(f"{self.base_url}/me/calendars/{calendar_id}/events")
        return self._get_json(f"{self.base_url}/me/events")

    def get_calendar_view(self, start_dt, end_dt, calendar_id=None):
        """Get calendar view (events in a time range).

        Args:
            start_dt: Start datetime (ISO 8601 string)
            end_dt: End datetime (ISO 8601 string)
            calendar_id: Optional calendar ID. If None, uses the default calendar.
        """
        if calendar_id:
            return self._get_json(
                f"{self.base_url}/me/calendars/{calendar_id}/calendarView",
                params={"startDateTime": start_dt, "endDateTime": end_dt}
            )
        return self._get_json(
            f"{self.base_url}/me/calendarView",
            params={"startDateTime": start_dt, "endDateTime": end_dt}
        )

    def _event_overlaps_window(self, event, window_start, window_end):
        """Check if an event overlaps with a time window.

        An event overlaps if its start is before window_end AND its end is after window_start.

        Args:
            event: Event dict with 'start' and 'end' containing 'dateTime' fields
            window_start: Start of window (ISO 8601 string)
            window_end: End of window (ISO 8601 string)

        Returns:
            True if event overlaps the window, False otherwise
        """
        from datetime import datetime

        try:
            # Parse event times (Graph returns dateTime without timezone in the field)
            event_start_str = event.get('start', {}).get('dateTime', '')
            event_end_str = event.get('end', {}).get('dateTime', '')

            if not event_start_str or not event_end_str:
                return False

            # Normalize: strip 'Z' suffix and truncate to seconds precision
            event_start_str = event_start_str.rstrip('Z')[:19]
            event_end_str = event_end_str.rstrip('Z')[:19]
            window_start_clean = window_start.rstrip('Z')[:19]
            window_end_clean = window_end.rstrip('Z')[:19]

            event_start = datetime.fromisoformat(event_start_str)
            event_end = datetime.fromisoformat(event_end_str)
            win_start = datetime.fromisoformat(window_start_clean)
            win_end = datetime.fromisoformat(window_end_clean)

            # Overlap: event starts before window ends AND event ends after window starts
            return event_start < win_end and event_end > win_start
        except (ValueError, TypeError):
            # If we can't parse, include the event to be safe
            return True

    def get_complete_calendar_view(self, start_dt, end_dt, calendar_id=None):
        """Get complete calendar view: series masters + events/occurrences in time range.

        This combines:
        1. Series masters (recurring events) - always included for recurrence info
        2. Single-instance events that overlap the time window
        3. Occurrences from calendarView within the time range

        Events are deduplicated so single events don't appear twice.

        Args:
            start_dt: Start datetime (ISO 8601 string)
            end_dt: End datetime (ISO 8601 string)
            calendar_id: Optional calendar ID. If None, uses the default calendar.

        Returns:
            dict with 'value' key containing merged list of events
        """
        # Get master events (includes single events and series masters)
        if calendar_id:
            masters_data = self._get_json(f"{self.base_url}/me/calendars/{calendar_id}/events")
        else:
            masters_data = self._get_json(f"{self.base_url}/me/events")
        masters = masters_data.get('value', [])

        # Get occurrences in time range
        if calendar_id:
            occurrences_data = self._get_json(
                f"{self.base_url}/me/calendars/{calendar_id}/calendarView",
                params={"startDateTime": start_dt, "endDateTime": end_dt}
            )
        else:
            occurrences_data = self._get_json(
                f"{self.base_url}/me/calendarView",
                params={"startDateTime": start_dt, "endDateTime": end_dt}
            )
        occurrences = occurrences_data.get('value', [])

        # Build result
        result = []
        master_ids = set()

        for event in masters:
            event_id = event.get('id')
            master_ids.add(event_id)

            if event.get('recurrence'):
                # Series master - always include for recurrence info
                event['_eventType'] = 'seriesMaster'
                result.append(event)
            else:
                # Single instance - only include if it overlaps the time window
                if self._event_overlaps_window(event, start_dt, end_dt):
                    event['_eventType'] = 'singleInstance'
                    result.append(event)

        # Add occurrences that aren't already in masters (by seriesMasterId or id)
        for occ in occurrences:
            occ_id = occ.get('id')
            series_master_id = occ.get('seriesMasterId')
            event_type = occ.get('type', '')

            # Skip if this is a single instance already included as a master
            if event_type == 'singleInstance' and occ_id in master_ids:
                continue

            # Mark occurrence type
            if series_master_id:
                occ['_eventType'] = 'occurrence'
            else:
                occ['_eventType'] = 'singleInstance'

            result.append(occ)

        return {'value': result}

    def _resolve_timezone(self, time_str):
        """Resolve timezone for a time string.

        If time_str ends with 'Z', returns ("UTC", time_str without Z).
        Otherwise, fetches user's mailbox timezone and returns (windows_tz, time_str).
        Note: Returns Windows timezone format as that's what MS Graph expects for event creation.
        """
        if time_str.endswith('Z'):
            return "UTC", time_str[:-1]
        else:
            tz_data = self.get_timezone()
            return tz_data['windows'], time_str

    def _resolve_timezone_arg(self, timezone):
        """Resolve timezone argument to Windows timezone format.

        Args:
            timezone: IANA timezone (e.g., "America/Vancouver"), Windows timezone,
                      or None to use AECH_DEFAULT_TIMEZONE env var (fallback: UTC).

        Returns:
            Windows timezone string for MS Graph API.
        """
        from .timezones import WINDOWS_TO_IANA_TIMEZONES, IANA_TO_WINDOWS_TIMEZONES

        if timezone is None:
            timezone = os.getenv("AECH_DEFAULT_TIMEZONE", "UTC")

        # Already a Windows timezone?
        if timezone in WINDOWS_TO_IANA_TIMEZONES:
            return timezone

        # IANA timezone - convert to Windows
        if timezone in IANA_TO_WINDOWS_TIMEZONES:
            return IANA_TO_WINDOWS_TIMEZONES[timezone]

        # Unknown - assume UTC
        return "UTC"

    def create_calendar_event(self, subject, start_time, end_time, content="", calendar_id=None, recurrence=None, timezone=None):
        """Create a calendar event.

        Args:
            subject: Event subject/title
            start_time: Start time (YYYY-MM-DDTHH:MM:SS format)
            end_time: End time (YYYY-MM-DDTHH:MM:SS format)
            content: Optional event body content (markdown)
            calendar_id: Optional calendar ID. If None, uses the default calendar.
            recurrence: Optional RFC 5545 RRULE string (e.g., "FREQ=DAILY;COUNT=10")
            timezone: Optional timezone (e.g., "America/Vancouver"). If None, uses AECH_DEFAULT_TIMEZONE or UTC.
        """
        windows_tz = self._resolve_timezone_arg(timezone)
        start_dt = start_time
        end_dt = end_time

        content_html = markdown_to_html(content) if content else ""
        data = {
            "subject": subject,
            "start": {"dateTime": start_dt, "timeZone": windows_tz},
            "end": {"dateTime": end_dt, "timeZone": windows_tz},
            "body": {"contentType": "HTML", "content": content_html}
        }

        # Add recurrence if specified
        if recurrence:
            recurrence_data = self._build_recurrence_pattern(recurrence, start_time)
            if recurrence_data:
                data["recurrence"] = recurrence_data

        if calendar_id:
            url = f"{self.base_url}/me/calendars/{calendar_id}/events"
        else:
            url = f"{self.base_url}/me/events"

        debug_log(f"Creating event: POST {url}")
        debug_log(f"Event data: {json.dumps(data, indent=2)}")
        resp = requests.post(url, json=data, headers=self._get_headers())
        debug_log(f"Response status: {resp.status_code}")
        debug_log(f"Response body: {resp.text[:500] if resp.text else '(empty)'}")
        if not resp.ok:
            raise Exception(f"Failed to create event: {resp.status_code} {resp.text}")
        try:
            return resp.json()
        except json.JSONDecodeError:
            raise Exception(f"Invalid response (status {resp.status_code}): {resp.text[:500] if resp.text else '(empty body)'}")

    def _build_recurrence_pattern(self, rrule, start_time):
        """Build MS Graph recurrence pattern from RFC 5545 RRULE string.

        Args:
            rrule: RFC 5545 RRULE string (e.g., "FREQ=DAILY", "FREQ=WEEKLY;BYDAY=MO,WE,FR")
            start_time: Event start time (for determining defaults)

        Returns:
            Recurrence dict for MS Graph API, or None if invalid

        Supported RRULE components:
            FREQ: DAILY, WEEKLY, MONTHLY, YEARLY (required)
            INTERVAL: Number (default 1)
            BYDAY: MO,TU,WE,TH,FR,SA,SU (for WEEKLY/DAILY)
            COUNT: Number of occurrences
            UNTIL: End date (YYYYMMDD format)
        """
        from datetime import datetime

        # Parse start_time to get day info for defaults
        try:
            if 'T' in start_time:
                dt = datetime.fromisoformat(start_time.replace('Z', '+00:00'))
            else:
                dt = datetime.fromisoformat(start_time)
        except ValueError:
            dt = datetime.now()

        # Parse RRULE components
        parts = {}
        for part in rrule.split(";"):
            if "=" in part:
                key, value = part.split("=", 1)
                parts[key.upper()] = value.upper()

        # FREQ is required
        if "FREQ" not in parts:
            debug_log(f"Invalid RRULE: missing FREQ component: {rrule}")
            return None

        freq = parts["FREQ"]
        interval = int(parts.get("INTERVAL", "1"))

        pattern_data = {"interval": interval}

        # Day code mapping for BYDAY
        day_map = {
            "MO": "monday", "TU": "tuesday", "WE": "wednesday",
            "TH": "thursday", "FR": "friday", "SA": "saturday", "SU": "sunday"
        }
        day_names = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]

        if freq == "DAILY":
            # Check if BYDAY specified - convert to WEEKLY (MS Graph doesn't support DAILY+BYDAY)
            if "BYDAY" in parts:
                pattern_data["type"] = "weekly"
                days = [day_map[d] for d in parts["BYDAY"].split(",") if d in day_map]
                pattern_data["daysOfWeek"] = days if days else [day_names[dt.weekday()]]
            else:
                pattern_data["type"] = "daily"

        elif freq == "WEEKLY":
            pattern_data["type"] = "weekly"
            if "BYDAY" in parts:
                days = [day_map[d] for d in parts["BYDAY"].split(",") if d in day_map]
                pattern_data["daysOfWeek"] = days if days else [day_names[dt.weekday()]]
            else:
                # Default to the day of the start_time
                pattern_data["daysOfWeek"] = [day_names[dt.weekday()]]

        elif freq == "MONTHLY":
            pattern_data["type"] = "absoluteMonthly"
            pattern_data["dayOfMonth"] = dt.day

        elif freq == "YEARLY":
            pattern_data["type"] = "absoluteYearly"
            pattern_data["dayOfMonth"] = dt.day
            pattern_data["month"] = dt.month

        else:
            debug_log(f"Unsupported FREQ in RRULE: {freq}")
            return None

        # Build the range
        range_data = {
            "type": "noEnd",
            "startDate": dt.strftime("%Y-%m-%d")
        }

        # Handle end conditions from RRULE (COUNT or UNTIL)
        if "COUNT" in parts:
            range_data["type"] = "numbered"
            range_data["numberOfOccurrences"] = int(parts["COUNT"])
        elif "UNTIL" in parts:
            # UNTIL format is YYYYMMDD or YYYYMMDDTHHMMSSZ
            until = parts["UNTIL"]
            if len(until) >= 8:
                range_data["type"] = "endDate"
                range_data["endDate"] = f"{until[:4]}-{until[4:6]}-{until[6:8]}"

        return {
            "pattern": pattern_data,
            "range": range_data
        }

    def delete_calendar_event(self, event_id, calendar_id=None):
        """Delete a calendar event.

        For recurring events, this deletes what the event_id refers to:
        - If event_id is the series master: deletes the entire series
        - If event_id is an occurrence: cancels just that instance

        Args:
            event_id: Event ID to delete
            calendar_id: Optional calendar ID. If None, uses the default calendar.
        """
        if calendar_id:
            url = f"{self.base_url}/me/calendars/{calendar_id}/events/{event_id}"
        else:
            url = f"{self.base_url}/me/events/{event_id}"
        resp = requests.delete(url, headers=self._get_headers())
        if not resp.ok:
            raise Exception(f"Failed to delete event: {resp.status_code} {resp.text}")
        return True

    # Calendar management methods
    def list_calendars(self):
        """List all calendars for the authenticated user."""
        return self._get_json(f"{self.base_url}/me/calendars")

    def get_calendar(self, calendar_id):
        """Get a specific calendar by ID."""
        return self._get_json(f"{self.base_url}/me/calendars/{calendar_id}")

    def create_calendar(self, name):
        """Create a new calendar.

        Args:
            name: Name for the new calendar

        Returns:
            Created calendar object with id, name, etc.
        """
        data = {"name": name}
        resp = requests.post(f"{self.base_url}/me/calendars", json=data, headers=self._get_headers())
        if not resp.ok:
            raise Exception(f"Failed to create calendar: {resp.status_code} {resp.text}")
        return resp.json()

    def delete_calendar(self, calendar_id):
        """Delete a calendar by ID.

        Args:
            calendar_id: Calendar ID to delete
        """
        resp = requests.delete(f"{self.base_url}/me/calendars/{calendar_id}", headers=self._get_headers())
        if not resp.ok:
            raise Exception(f"Failed to delete calendar: {resp.status_code} {resp.text}")
        return True

    def resolve_calendar_id(self, calendar_ref):
        """Resolve a calendar reference (name or ID) to a calendar ID.

        Args:
            calendar_ref: Calendar name or ID

        Returns:
            Calendar ID string, or None if not found
        """
        if not calendar_ref:
            return None

        # First, try to use it directly as an ID (check if it looks like a Graph ID)
        # Graph calendar IDs are typically long base64-like strings
        if len(calendar_ref) > 50 and '=' in calendar_ref:
            return calendar_ref

        # Otherwise, search by name
        calendars = self.list_calendars()
        for cal in calendars.get('value', []):
            if cal.get('name', '').lower() == calendar_ref.lower():
                return cal.get('id')
            if cal.get('id') == calendar_ref:
                return calendar_ref

        return None

    # System calendars to exclude when using --all (these are auto-created by M365)
    SYSTEM_CALENDAR_NAMES = {'calendar', 'birthdays', 'united states holidays'}

    def get_all_calendar_events(self, start_dt=None, end_dt=None, exclude_system=True, complete_view=False):
        """Get events from ALL calendars (default + all additional calendars).

        This is useful for polling all user calendars in one call.

        Args:
            start_dt: Optional start datetime (ISO 8601 string) for calendarView
            end_dt: Optional end datetime (ISO 8601 string) for calendarView
            exclude_system: If True, exclude system calendars (Calendar, Birthdays, holidays)
            complete_view: If True, get both masters and occurrences (merged, deduplicated)

        Returns:
            List of events with _calendarId and _calendarName injected into each event
        """
        all_events = []
        calendars = self.list_calendars()

        for cal in calendars.get('value', []):
            cal_id = cal.get('id')
            cal_name = cal.get('name', 'Unknown')

            if not cal_id:
                continue

            # Skip system calendars if requested
            if exclude_system and cal_name.lower() in self.SYSTEM_CALENDAR_NAMES:
                continue

            try:
                if complete_view and start_dt and end_dt:
                    # Use complete view: masters + occurrences merged
                    debug_log(f"Querying complete view for {cal_name}: {start_dt} to {end_dt}")
                    events_data = self.get_complete_calendar_view(start_dt, end_dt, calendar_id=cal_id)
                    debug_log(f"  Got {len(events_data.get('value', []))} events")
                elif start_dt and end_dt:
                    # Use calendarView for time-based query
                    debug_log(f"Querying calendarView for {cal_name}: {start_dt} to {end_dt}")
                    events_data = self._get_json(
                        f"{self.base_url}/me/calendars/{cal_id}/calendarView",
                        params={"startDateTime": start_dt, "endDateTime": end_dt}
                    )
                    debug_log(f"  Got {len(events_data.get('value', []))} events")
                else:
                    # Get all events
                    events_data = self._get_json(f"{self.base_url}/me/calendars/{cal_id}/events")

                for event in events_data.get('value', []):
                    # Inject calendar metadata into each event
                    event['_calendarId'] = cal_id
                    event['_calendarName'] = cal_name
                    event['_isDefaultCalendar'] = cal.get('isDefaultCalendar', False)
                    all_events.append(event)

            except Exception as e:
                debug_log(f"Failed to get events from calendar '{cal_name}': {e}")
                continue

        return all_events

    def get_emails(self, top=10, include_attachments=False, unread_only=False, user_id: str = None):
        # Fetch headers for security checks
        base_path = self._get_base_path(user_id)
        query = f"{base_path}/mailFolders/inbox/messages?$top={top}&$select=subject,from,receivedDateTime,internetMessageHeaders,bodyPreview,isRead,conversationId,conversationIndex,body,hasAttachments"
        
        if unread_only:
            query += "&$filter=isRead eq false"
            
        if include_attachments:
            query += "&$expand=attachments"
        return self._get_json(query)

    def send_email(self, to_email, subject, content, attachments=None):
        check_outbound_allowed(to_email, get_email_whitelist_outgoing())
        content_html = markdown_to_html(content) if content else ""
        message = {
            "subject": subject,
            "body": {
                "contentType": "HTML",
                "content": content_html
            },
            "toRecipients": [
                {
                    "emailAddress": {
                        "address": to_email
                    }
                }
            ]
        }

        if attachments:
            import base64
            import os
            atts = []
            for path in attachments:
                if os.path.exists(path):
                    with open(path, "rb") as f:
                        content_bytes = base64.b64encode(f.read()).decode("utf-8")
                    atts.append({
                        "@odata.type": "#microsoft.graph.fileAttachment",
                        "name": os.path.basename(path),
                        "contentBytes": content_bytes
                    })
            if atts:
                message["attachments"] = atts

        data = {"message": message}
        return requests.post(f"{self.base_url}/me/sendMail", json=data, headers=self._get_headers())

    def get_attachments(self, message_id):
        return self._get_json(f"{self.base_url}/me/messages/{message_id}/attachments")

    def get_attachment(self, message_id, attachment_id):
        return self._get_json(f"{self.base_url}/me/messages/{message_id}/attachments/{attachment_id}")

    def download_attachment(self, message_id, attachment_id):
        # For file attachments, the content is in the 'contentBytes' field of the attachment object usually, 
        # but for large files or specific types, $value might be needed. 
        # The standard way for small-medium files is getting the attachment object which has contentBytes (base64).
        # Let's check the attachment type first or just return the raw bytes from $value if supported.
        # Graph API: GET /me/messages/{id}/attachments/{id}/$value returns raw content.
        return requests.get(f"{self.base_url}/me/messages/{message_id}/attachments/{attachment_id}/$value", headers=self._get_headers())

    def search_emails(self, query):
        # Use $search for advanced search
        # Note: $search requires "ConsistencyLevel: eventual" header usually, but for messages it might work without if simple.
        # Let's add the header to be safe.
        headers = self._get_headers()
        headers['ConsistencyLevel'] = 'eventual'
        # $search syntax: "keyword"
        return self._get_json(f"{self.base_url}/me/messages?$search=\"{query}\"&$top=20", extra_headers=headers)

    def get_or_create_chat(self, user_email: str) -> dict:
        """Get or create a 1:1 chat with a user by email.

        If a chat already exists with this user, returns the existing chat.
        Otherwise creates a new oneOnOne chat.

        Args:
            user_email: Email address of the user to chat with

        Returns:
            Chat object with 'id' field containing the chat ID
        """
        check_outbound_allowed(user_email, get_email_whitelist_outgoing())
        # Get the authenticated user's ID
        me = self.get_me()
        my_id = me.get("id")

        # Create chat request - Graph API is idempotent, returns existing chat if one exists
        data = {
            "chatType": "oneOnOne",
            "members": [
                {
                    "@odata.type": "#microsoft.graph.aadUserConversationMember",
                    "roles": ["owner"],
                    "user@odata.bind": f"https://graph.microsoft.com/v1.0/users('{my_id}')"
                },
                {
                    "@odata.type": "#microsoft.graph.aadUserConversationMember",
                    "roles": ["owner"],
                    "user@odata.bind": f"https://graph.microsoft.com/v1.0/users('{user_email}')"
                }
            ]
        }

        resp = requests.post(f"{self.base_url}/chats", json=data, headers=self._get_headers())
        if not resp.ok:
            raise Exception(f"Failed to get or create chat: {resp.status_code} {resp.text}")
        return resp.json()

    def send_chat_message(self, chat_id, content, hosted_contents: list[dict] | None = None):
        """Send a message to a Teams chat.

        Args:
            chat_id: The chat ID to send to
            content: Message content (markdown or HTML)
            hosted_contents: Optional list of inline images. Each dict should have:
                - contentBytes: base64-encoded image data
                - contentType: MIME type (e.g., "image/png")
        """
        content_html = markdown_to_html(content) if content else ""
        data = {
            "body": {
                "contentType": "html",
                "content": content_html
            }
        }
        if hosted_contents:
            data["hostedContents"] = [
                {
                    "@microsoft.graph.temporaryId": str(i + 1),
                    "contentBytes": hc["contentBytes"],
                    "contentType": hc["contentType"]
                }
                for i, hc in enumerate(hosted_contents)
            ]
        return requests.post(f"{self.base_url}/chats/{chat_id}/messages", json=data, headers=self._get_headers()).json()

    def send_channel_message(self, team_id, channel_id, content, hosted_contents: list[dict] | None = None):
        """Send a message to a Teams channel."""
        content_html = markdown_to_html(content) if content else ""
        data = {
            "body": {
                "contentType": "html",
                "content": content_html
            }
        }
        if hosted_contents:
            data["hostedContents"] = [
                {
                    "@microsoft.graph.temporaryId": str(i + 1),
                    "contentBytes": hc["contentBytes"],
                    "contentType": hc["contentType"]
                }
                for i, hc in enumerate(hosted_contents)
            ]
        return requests.post(f"{self.base_url}/teams/{team_id}/channels/{channel_id}/messages", json=data, headers=self._get_headers()).json()

    def set_chat_reaction(self, chat_id, message_id, reaction_type: str):
        """Add a reaction to a chat message."""
        resp = requests.post(
            f"{self.base_url}/chats/{chat_id}/messages/{message_id}/setReaction",
            json={"reactionType": reaction_type},
            headers=self._get_headers(),
        )
        if not resp.ok:
            raise Exception(f"Failed to set chat reaction: {resp.status_code} {resp.text}")
        return True

    def unset_chat_reaction(self, chat_id, message_id, reaction_type: str):
        """Remove a reaction from a chat message."""
        resp = requests.post(
            f"{self.base_url}/chats/{chat_id}/messages/{message_id}/unsetReaction",
            json={"reactionType": reaction_type},
            headers=self._get_headers(),
        )
        if not resp.ok:
            raise Exception(f"Failed to unset chat reaction: {resp.status_code} {resp.text}")
        return True

    def set_channel_reaction(self, team_id, channel_id, message_id, reaction_type: str):
        """Add a reaction to a channel message."""
        resp = requests.post(
            f"{self.base_url}/teams/{team_id}/channels/{channel_id}/messages/{message_id}/setReaction",
            json={"reactionType": reaction_type},
            headers=self._get_headers(),
        )
        if not resp.ok:
            raise Exception(f"Failed to set channel reaction: {resp.status_code} {resp.text}")
        return True

    def unset_channel_reaction(self, team_id, channel_id, message_id, reaction_type: str):
        """Remove a reaction from a channel message."""
        resp = requests.post(
            f"{self.base_url}/teams/{team_id}/channels/{channel_id}/messages/{message_id}/unsetReaction",
            json={"reactionType": reaction_type},
            headers=self._get_headers(),
        )
        if not resp.ok:
            raise Exception(f"Failed to unset channel reaction: {resp.status_code} {resp.text}")
        return True

    def reply_channel_message(self, team_id, channel_id, message_id, content, hosted_contents: list[dict] | None = None):
        """Reply to a Teams channel message."""
        content_html = markdown_to_html(content) if content else ""
        data = {
            "body": {
                "contentType": "html",
                "content": content_html
            }
        }
        if hosted_contents:
            data["hostedContents"] = [
                {
                    "@microsoft.graph.temporaryId": str(i + 1),
                    "contentBytes": hc["contentBytes"],
                    "contentType": hc["contentType"]
                }
                for i, hc in enumerate(hosted_contents)
            ]
        return requests.post(f"{self.base_url}/teams/{team_id}/channels/{channel_id}/messages/{message_id}/replies", json=data, headers=self._get_headers()).json()

    def get_presence(self):
        return self._get_json(f"{self.base_url}/me/presence")

    def set_presence(self, availability, activity):
        # availability: Available, Busy, DoNotDisturb, BeRightBack, Away, Offline
        # activity: Available, Busy, DoNotDisturb, BeRightBack, Away, OffWork
        data = {
            "sessionId": self.auth.app.get_accounts()[0]['home_account_id'], # Required for presence
            "availability": availability,
            "activity": activity
        }
        return requests.post(f"{self.base_url}/me/presence/setUserPreferredPresence", json=data, headers=self._get_headers())

    def get_contacts(self):
        return self._get_json(f"{self.base_url}/me/contacts")

    def get_timezone(self, user_principal_name=None):
        """Get timezone for a user, returning both Windows and IANA formats.

        Returns:
            dict with 'windows' and 'iana' keys, e.g.:
            {"windows": "Pacific Standard Time", "iana": "America/Los_Angeles"}
        """
        from .timezones import WINDOWS_TO_IANA_TIMEZONES, IANA_TO_WINDOWS_TIMEZONES

        if user_principal_name:
            url = f"{self.base_url}/users/{user_principal_name}/mailboxSettings/timeZone"
        else:
            url = f"{self.base_url}/me/mailboxSettings/timeZone"
        try:
            data = self._get_json(url)
            windows_tz = data.get("value")
        except Exception:
            windows_tz = None

        if not windows_tz:
            # Fallback to AECH_DEFAULT_TIMEZONE if timezone cannot be retrieved (e.g., 204 No Content)
            default_tz = os.getenv("AECH_DEFAULT_TIMEZONE", "UTC")
            # default_tz could be IANA or Windows format
            if default_tz in WINDOWS_TO_IANA_TIMEZONES:
                windows_tz = default_tz
            elif default_tz in IANA_TO_WINDOWS_TIMEZONES:
                windows_tz = IANA_TO_WINDOWS_TIMEZONES[default_tz]
            else:
                windows_tz = "UTC"

        iana_tz = WINDOWS_TO_IANA_TIMEZONES.get(windows_tz, "UTC")
        return {"windows": windows_tz, "iana": iana_tz}

    def find_meeting_times(self, attendees, duration=30):
        # attendees: list of email strings
        attendee_list = []
        for email in attendees:
            attendee_list.append({
                "emailAddress": {"address": email},
                "type": "Required"
            })
        
        data = {
            "attendees": attendee_list,
            "meetingDuration": f"PT{duration}M",
            "maxCandidates": 5,
            "isOrganizerOptional": True
        }
        return requests.post(f"{self.base_url}/me/findMeetingTimes", json=data, headers=self._get_headers()).json()

    def update_event(self, event_id, start=None, end=None, location=None, subject=None, recurrence=None, calendar_id=None, timezone=None):
        """Update a calendar event.

        Args:
            event_id: Event ID to update
            start: New start time (YYYY-MM-DDTHH:MM:SS format)
            end: New end time (YYYY-MM-DDTHH:MM:SS format)
            location: New location
            subject: New subject/title
            recurrence: New RFC 5545 RRULE string, or "none" to remove recurrence
            calendar_id: Optional calendar ID. If None, uses the default calendar.
            timezone: Optional timezone (e.g., "America/Vancouver"). If None, uses AECH_DEFAULT_TIMEZONE or UTC.

        Returns:
            Updated event object
        """
        data = {}
        if start and end:
            windows_tz = self._resolve_timezone_arg(timezone)
            data["start"] = {"dateTime": start, "timeZone": windows_tz}
            data["end"] = {"dateTime": end, "timeZone": windows_tz}
        if location:
            data["location"] = {"displayName": location}
        if subject:
            data["subject"] = subject

        # Handle recurrence modification
        if recurrence is not None:
            if recurrence.lower() == "none":
                # Remove recurrence by setting to null
                data["recurrence"] = None
            else:
                # Build new recurrence pattern from RRULE
                recurrence_data = self._build_recurrence_pattern(recurrence, start or "")
                if recurrence_data:
                    data["recurrence"] = recurrence_data

        if calendar_id:
            url = f"{self.base_url}/me/calendars/{calendar_id}/events/{event_id}"
        else:
            url = f"{self.base_url}/me/events/{event_id}"

        resp = requests.patch(url, json=data, headers=self._get_headers())
        if not resp.ok:
            raise Exception(f"Failed to update event: {resp.status_code} {resp.text}")
        return resp.json()

    def get_joined_teams(self):
        return self._get_json(f"{self.base_url}/me/joinedTeams")

    def get_channels(self, team_id):
        return self._get_json(f"{self.base_url}/teams/{team_id}/channels")

    def get_channel_messages(self, team_id, channel_id):
        return self._get_json(
            f"{self.base_url}/teams/{team_id}/channels/{channel_id}/messages",
            params={"$top": 50}
        )

    def get_chat_messages(self, chat_id, since: str = None):
        """Get messages from a chat.

        Args:
            chat_id: The chat ID
            since: Optional ISO timestamp to filter messages modified after this time
        """
        params = {"$top": 50}
        if since:
            # Filter by lastModifiedDateTime, requires $orderby on same field
            params["$filter"] = f"lastModifiedDateTime gt {since}"
            params["$orderby"] = "lastModifiedDateTime desc"
        return self._get_json(
            f"{self.base_url}/chats/{chat_id}/messages",
            params=params
        )
    
    def get_recent_chats(self):
        """Get all chats with pagination.

        Follows @odata.nextLink to collect all chats, not just the first page.
        """
        from .config import debug_log

        url = f"{self.base_url}/chats"
        params = {
            "$expand": "members",
            "$top": 50  # Request more per page
        }

        all_chats = []
        page_count = 0
        while url:
            response = self._get_json(url, params=params if params else None)
            chats = response.get('value', [])
            all_chats.extend(chats)
            page_count += 1
            debug_log(f"  Fetched page {page_count}: {len(chats)} chats (total: {len(all_chats)})")
            url = response.get('@odata.nextLink')
            params = None  # nextLink includes full query

        return {"value": all_chats}

    def reply_email(self, message_id, content, attachments=None):
        # Fetch the original message to include its body in the reply
        original_msg = requests.get(
            f"{self.base_url}/me/messages/{message_id}?$select=from,toRecipients,receivedDateTime,body,subject",
            headers=self._get_headers()
        ).json()
        
        # Extract original message details
        sender_name = original_msg.get('from', {}).get('emailAddress', {}).get('name', 'Unknown')
        sender_email = original_msg.get('from', {}).get('emailAddress', {}).get('address', '')
        check_outbound_allowed(sender_email, get_email_whitelist_outgoing())
        received_date = original_msg.get('receivedDateTime', '')
        original_body_html = original_msg.get('body', {}).get('content', '')
        subject = original_msg.get('subject', 'No Subject')
        
        # Get To recipients
        to_recipients = original_msg.get('toRecipients', [])
        to_list = []
        for recipient in to_recipients:
            name = recipient.get('emailAddress', {}).get('name', '')
            email = recipient.get('emailAddress', {}).get('address', '')
            if name and email:
                to_list.append(f"{name} &lt;{email}&gt;")
            elif email:
                to_list.append(email)
        to_string = ", ".join(to_list) if to_list else "Unknown"
        
        # Format the received date for display (Full day name)
        try:
            from datetime import datetime
            dt = datetime.fromisoformat(received_date.replace('Z', '+00:00'))
            formatted_date = dt.strftime('%A, %B %d, %Y at %I:%M %p')
        except:
            formatted_date = received_date
        
        # Build the reply content with history
        new_content_html = markdown_to_html(content) if content else ""
        
        # Create the quote header (Gmail/Outlook style)
        quote_header = f"""<br><br><hr>
<p><b>From:</b> {sender_name} &lt;{sender_email}&gt;<br>
<b>Date:</b> {formatted_date}<br>
<b>To:</b> {to_string}<br>
<b>Subject:</b> {subject}</p>
<br>"""
        
        # Combine new content with original message
        full_body_html = new_content_html + quote_header + original_body_html
        
        if not attachments:
            # Simple reply-all if no attachments
            data = {
                "comment": "",
                "message": {
                    "body": {
                        "contentType": "HTML",
                        "content": full_body_html
                    }
                }
            }
            return requests.post(f"{self.base_url}/me/messages/{message_id}/replyAll", json=data, headers=self._get_headers())
        
        # Complex reply-all (Draft -> Upload -> Send)
        # 1. Create Reply-All Draft
        draft = self.create_reply_draft(message_id)
        draft_id = draft.get('id')
        
        # 2. Update draft body with the full content including history
        # We need to directly update with HTML instead of using the update_message method
        # which would convert markdown to HTML again
        data = {
            "body": {
                "contentType": "HTML",
                "content": full_body_html
            }
        }
        requests.patch(f"{self.base_url}/me/messages/{draft_id}", json=data, headers=self._get_headers()).json()
        
        # 3. Upload Attachments
        for path in attachments:
            self.add_attachment(draft_id, path)
            
        # 4. Send
        return self.send_message(draft_id)

    def create_reply_draft(self, message_id):
        # Creates a reply-all draft for the specified message
        return requests.post(f"{self.base_url}/me/messages/{message_id}/createReplyAll", headers=self._get_headers()).json()

    def update_message(self, message_id, body=None):
        data = {}
        if body:
            body_html = markdown_to_html(body)
            data["body"] = {
                "contentType": "HTML",
                "content": body_html
            }
        if data:
            return requests.patch(f"{self.base_url}/me/messages/{message_id}", json=data, headers=self._get_headers()).json()

    def add_attachment(self, message_id, file_path):
        import base64
        import os
        
        filename = os.path.basename(file_path)
        with open(file_path, "rb") as f:
            content_bytes = base64.b64encode(f.read()).decode("utf-8")
            
        data = {
            "@odata.type": "#microsoft.graph.fileAttachment",
            "name": filename,
            "contentBytes": content_bytes
        }
        return requests.post(f"{self.base_url}/me/messages/{message_id}/attachments", json=data, headers=self._get_headers()).json()

    def send_message(self, message_id):
        return requests.post(f"{self.base_url}/me/messages/{message_id}/send", headers=self._get_headers())

    def get_drive_items(self, folder_id=None):
        if folder_id:
            url = f"{self.base_url}/me/drive/items/{folder_id}/children"
        else:
            url = f"{self.base_url}/me/drive/root/children"
        return requests.get(url, headers=self._get_headers()).json()

    def upload_file(self, local_path, folder_id=None):
        filename = os.path.basename(local_path)
        with open(local_path, 'rb') as f:
            content = f.read()
        
        if folder_id:
            url = f"{self.base_url}/me/drive/items/{folder_id}:/{filename}:/content"
        else:
            url = f"{self.base_url}/me/drive/root:/{filename}:/content"
            
        return requests.put(url, data=content, headers=self._get_headers()).json()

    def create_sharing_link(self, file_id, link_type="view", scope="organization"):
        """Create a sharing link for a OneDrive file.

        Args:
            file_id: The OneDrive item ID
            link_type: "view" (read-only) or "edit"
            scope: "anonymous", "organization", or "users"

        Returns:
            dict with 'link' containing 'webUrl'
        """
        data = {
            "type": link_type,
            "scope": scope
        }
        resp = requests.post(
            f"{self.base_url}/me/drive/items/{file_id}/createLink",
            json=data,
            headers=self._get_headers()
        )
        if not resp.ok:
            raise Exception(f"Failed to create sharing link: {resp.status_code} {resp.text}")
        return resp.json()

    def upload_and_share(self, local_path, folder_id=None, link_type="view", scope="organization"):
        """Upload a file to OneDrive and return a sharing link.

        Args:
            local_path: Path to local file
            folder_id: Optional OneDrive folder ID
            link_type: "view" or "edit"
            scope: "anonymous", "organization", or "users"

        Returns:
            tuple of (file_name, sharing_url)
        """
        # Upload the file
        upload_result = self.upload_file(local_path, folder_id)
        file_id = upload_result.get('id')
        if not file_id:
            raise Exception(f"Upload failed: {upload_result}")

        # Create sharing link
        link_result = self.create_sharing_link(file_id, link_type, scope)
        sharing_url = link_result.get('link', {}).get('webUrl')
        if not sharing_url:
            raise Exception(f"Failed to get sharing URL: {link_result}")

        return os.path.basename(local_path), sharing_url

    def download_file(self, file_id):
        # Returns the raw content
        return requests.get(f"{self.base_url}/me/drive/items/{file_id}/content", headers=self._get_headers())

    def download_file_by_url(self, url: str):
        """Download a file from a SharePoint/OneDrive URL.

        Supports URLs like:
        - https://tenant.sharepoint.com/sites/.../_api/v2.0/drives/.../items/.../content
        - https://tenant.sharepoint.com/:x:/r/sites/.../filename.xlsx (sharing links)
        - https://tenant-my.sharepoint.com/personal/.../_layouts/15/download.aspx?...
        - https://tenant-my.sharepoint.com/personal/user_domain/Documents/... (direct paths)

        Returns:
            tuple of (content_bytes, filename)
        """
        import base64
        import re
        from urllib.parse import unquote, urlparse
        from .config import debug_log

        headers = self._get_headers()

        # Cache-busting headers to get latest file version
        no_cache_headers = {
            'Cache-Control': 'no-cache, no-store, must-revalidate',
            'Pragma': 'no-cache',
        }

        # 1. Handle sharing links via /shares endpoint (URLs with :x:, :w:, :p:, :b:)
        if "sharepoint.com" in url and (":x:" in url or ":w:" in url or ":p:" in url or ":b:" in url):
            encoded_url = base64.urlsafe_b64encode(url.encode()).decode().rstrip("=")
            share_url = f"{self.base_url}/shares/u!{encoded_url}/driveItem"
            try:
                item = self._get_json(share_url)
                download_url = item.get("@microsoft.graph.downloadUrl")
                if download_url:
                    # Add cache-busting query param
                    import time
                    cache_bust = f"{'&' if '?' in download_url else '?'}_cb={int(time.time())}"
                    resp = requests.get(download_url + cache_bust, headers=no_cache_headers)
                    if resp.ok:
                        filename = item.get("name", "downloaded_file")
                        return resp.content, filename
            except Exception as e:
                debug_log(f"Sharing link resolution failed: {e}")
                pass  # Fall through to other methods

        # 2. Handle direct SharePoint personal drive paths
        # Pattern: https://tenant-my.sharepoint.com/personal/user_domain/Documents/path/file.ext
        personal_match = re.match(
            r'https://([^/]+)-my\.sharepoint\.com/personal/([^/]+)/Documents/(.+)',
            url
        )
        if personal_match:
            tenant, user_folder, file_path = personal_match.groups()
            file_path = unquote(file_path)  # URL decode
            debug_log(f"Personal drive path detected: user={user_folder}, path={file_path}")

            # For files shared with us from another user's OneDrive, we need to use the
            # sites API to access the personal site directly
            # The hostname includes the full personal site path in one segment
            site_host = f"{tenant}-my.sharepoint.com"

            # Try approach 1: Use the /users endpoint if we have their email
            # The user_folder typically is email with underscores: steven_aech_ai
            # Format: localpart_domain_tld -> localpart@domain.tld
            # We need to find the @ position - look for domain_tld pattern at end
            parts = user_folder.split("_")
            if len(parts) >= 2:
                # Assume last two parts are domain_tld (e.g., aech_ai)
                tld = parts[-1]
                domain = parts[-2]
                local_part = "_".join(parts[:-2])  # Keep underscores in local part
                user_email = f"{local_part}@{domain}.{tld}"
                debug_log(f"Derived user email: {user_email}")

                try:
                    encoded_path = file_path.replace(" ", "%20")
                    user_drive_url = f"{self.base_url}/users/{user_email}/drive/root:/{encoded_path}:/content"
                    debug_log(f"Trying user drive path: {user_drive_url}")
                    resp = requests.get(user_drive_url, headers=headers, allow_redirects=True)
                    if resp.ok:
                        filename = file_path.split('/')[-1]
                        return resp.content, filename
                    debug_log(f"User drive path failed: {resp.status_code} - {resp.text[:200] if resp.text else ''}")
                except Exception as e:
                    debug_log(f"User drive error: {e}")

            # Try approach 2: sites API with proper hostname,sitepath format
            try:
                encoded_path = file_path.replace(" ", "%20")
                # Format: /sites/{hostname}:/personal/{user}:/drive/root:/{path}:/content
                site_url = f"{self.base_url}/sites/{site_host}:/personal/{user_folder}:/drive/root:/{encoded_path}:/content"
                debug_log(f"Trying site path: {site_url}")
                resp = requests.get(site_url, headers=headers, allow_redirects=True)
                if resp.ok:
                    filename = file_path.split('/')[-1]
                    return resp.content, filename
                debug_log(f"Site drive path failed: {resp.status_code} - {resp.text[:200] if resp.text else ''}")
            except Exception as e:
                debug_log(f"Site drive error: {e}")

            # Also try /me/drive (if it's the current user's OneDrive)
            try:
                graph_url = f"{self.base_url}/me/drive/root:/{file_path}:/content"
                debug_log(f"Trying Graph /me/drive path: {graph_url}")
                resp = requests.get(graph_url, headers=headers, allow_redirects=True)
                if resp.ok:
                    filename = file_path.split('/')[-1]
                    return resp.content, filename
                debug_log(f"Graph /me/drive failed: {resp.status_code}")
            except Exception as e:
                debug_log(f"Graph /me/drive error: {e}")

        # 3. Handle SharePoint team site paths
        # Pattern: https://tenant.sharepoint.com/sites/sitename/path/file.ext
        site_match = re.match(
            r'https://([^/]+\.sharepoint\.com)/sites/([^/]+)/(.+)',
            url
        )
        if site_match:
            host, site_name, file_path = site_match.groups()
            file_path = unquote(file_path)
            debug_log(f"Team site path detected: site={site_name}, path={file_path}")
            try:
                site_url = f"{self.base_url}/sites/{host}:/sites/{site_name}:/drive/root:/{file_path}:/content"
                resp = requests.get(site_url, headers=headers, allow_redirects=True)
                if resp.ok:
                    filename = file_path.split('/')[-1]
                    return resp.content, filename
            except Exception as e:
                debug_log(f"Team site drive error: {e}")

        # 4. Try direct download with auth headers as last resort
        resp = requests.get(url, headers=headers, allow_redirects=True)
        if resp.ok:
            cd = resp.headers.get("Content-Disposition", "")
            filename = "downloaded_file"
            if "filename=" in cd:
                match = re.search(r'filename[*]?=["\']?([^"\';\n]+)', cd)
                if match:
                    filename = match.group(1).strip()
            elif "filename*=" in cd:
                match = re.search(r"filename\*=UTF-8''([^;\n]+)", cd)
                if match:
                    filename = unquote(match.group(1).strip())
            else:
                # Try to get filename from URL
                parsed = urlparse(url)
                if parsed.path:
                    filename = unquote(parsed.path.split('/')[-1]) or filename
            return resp.content, filename

        raise Exception(f"Failed to download from URL: {resp.status_code} {resp.text}")

    def fetch_teams_attachment_content(self, attachment: dict) -> dict | None:
        """Fetch content for a Teams message attachment and return enriched attachment dict.

        Teams file attachments are stored in OneDrive/SharePoint. This method:
        1. Uses the contentUrl to resolve the file via /shares endpoint
        2. Downloads the content and base64 encodes it
        3. Returns the attachment dict with added contentBytes field

        Args:
            attachment: Teams attachment dict with contentUrl, name, contentType, etc.

        Returns:
            Enriched attachment dict with contentBytes (base64), or None on failure
        """
        import base64
        from .config import debug_log

        content_url = attachment.get("contentUrl")
        if not content_url:
            debug_log(f"Attachment has no contentUrl: {attachment.get('name', 'unknown')}")
            return attachment  # Return as-is without content

        try:
            # Try to download via the existing method
            content_bytes, filename = self.download_file_by_url(content_url)

            # Create enriched attachment with base64 content
            enriched = attachment.copy()
            enriched["contentBytes"] = base64.b64encode(content_bytes).decode("utf-8")
            enriched["size"] = len(content_bytes)
            if not enriched.get("name"):
                enriched["name"] = filename
            debug_log(f"Fetched attachment: {enriched.get('name')} ({len(content_bytes)} bytes)")
            return enriched

        except Exception as e:
            debug_log(f"Failed to fetch attachment content: {e}")
            # Return attachment without content - caller can still see metadata
            enriched = attachment.copy()
            enriched["_fetchError"] = str(e)
            return enriched

    def fetch_hosted_content(self, url: str) -> tuple[bytes, str] | None:
        """Fetch Teams hosted content (inline images) from Graph API.

        Args:
            url: The hostedContents URL from an img src in message body

        Returns:
            tuple of (content_bytes, content_type) or None on failure
        """
        from .config import debug_log

        try:
            resp = requests.get(url, headers=self._get_headers())
            if resp.ok:
                content_type = resp.headers.get("Content-Type", "application/octet-stream")
                debug_log(f"Fetched hosted content: {len(resp.content)} bytes, type={content_type}")
                return resp.content, content_type
            else:
                debug_log(f"Failed to fetch hosted content: {resp.status_code}")
                return None
        except Exception as e:
            debug_log(f"Error fetching hosted content: {e}")
            return None

    def extract_and_fetch_inline_images(self, message: dict) -> list[dict]:
        """Extract inline images from Teams message body and fetch their content.

        Teams pasted images appear as <img> tags in the HTML body with src pointing
        to hostedContents endpoint. This extracts and fetches them.

        Args:
            message: Teams message dict with body.content

        Returns:
            List of inline image dicts with id, contentType, contentBytes (base64), etc.
        """
        import base64
        import re
        from .config import debug_log

        body = message.get("body", {})
        content = body.get("content", "")

        if not content or body.get("contentType") != "html":
            return []

        # Find all img tags with hostedContents URLs
        # Pattern: <img src="..." ... itemid="..."> where src contains hostedContents
        # Need to capture both src and itemid which can appear in any order
        img_pattern = r'<img\s+[^>]*src="([^"]*hostedContents[^"]*)"[^>]*>'
        src_matches = re.findall(img_pattern, content, re.IGNORECASE)

        # Also extract itemid separately for each img
        itemid_pattern = r'<img\s+[^>]*itemid="([^"]*)"[^>]*>'
        itemid_matches = re.findall(itemid_pattern, content, re.IGNORECASE)

        # Pair them up (assumes same order)
        matches = []
        for i, src in enumerate(src_matches):
            item_id = itemid_matches[i] if i < len(itemid_matches) else ""
            matches.append((src, item_id))

        inline_images = []
        for src_url, item_id in matches:
            # Clean up the URL (HTML entities)
            src_url = src_url.replace("&amp;", "&")

            debug_log(f"Found inline image: itemid={item_id}, url={src_url[:80]}...")

            result = self.fetch_hosted_content(src_url)
            if result:
                content_bytes, content_type = result
                # Determine file extension from content type
                ext_map = {
                    "image/png": "png",
                    "image/jpeg": "jpg",
                    "image/gif": "gif",
                    "image/webp": "webp",
                }
                ext = ext_map.get(content_type, "bin")
                filename = f"{item_id or 'image'}.{ext}"

                inline_images.append({
                    "id": item_id,
                    "name": filename,
                    "contentType": content_type,
                    "contentBytes": base64.b64encode(content_bytes).decode("utf-8"),
                    "size": len(content_bytes),
                    "sourceUrl": src_url,
                })
            else:
                inline_images.append({
                    "id": item_id,
                    "sourceUrl": src_url,
                    "_fetchError": "Failed to fetch hosted content",
                })

        return inline_images

    def get_email_read_status(self, message_id):
        response = requests.get(f"{self.base_url}/me/messages/{message_id}?$select=isRead", headers=self._get_headers())
        response.raise_for_status()
        return response.json()

    def set_email_read_status(self, message_id, is_read):
        data = {
            "isRead": is_read
        }
        response = requests.patch(f"{self.base_url}/me/messages/{message_id}", json=data, headers=self._get_headers())
        response.raise_for_status()
        return response.json()

    def get_mail_folders(self, user_id: str = None):
        """Get all mail folders with pagination support.
        
        Returns folder metadata including id, displayName, totalItemCount, unreadItemCount.
        Follows @odata.nextLink to collect all folders.
        """
        base_path = self._get_base_path(user_id)
        url = f"{base_path}/mailFolders"
        params = {
            "$select": "id,displayName,totalItemCount,unreadItemCount,parentFolderId",
            "$top": 100
        }
        
        all_folders = []
        while url:
            response = self._get_json(url, params=params if params else None)
            all_folders.extend(response.get('value', []))
            url = response.get('@odata.nextLink')
            params = None  # nextLink includes full query
            
        return {"value": all_folders}
    
    def get_folder_messages(self, folder_id: str, top: int = 50, include_attachments: bool = False, user_id: str = None):
        """Get messages from a specific mail folder.
        
        Args:
            folder_id: The mail folder ID
            top: Maximum number of messages to return (default 50, max 100)
            include_attachments: Whether to expand attachments
            user_id: Optional delegate user ID
            
        Returns:
            Dict with 'value' containing list of message objects
        """
        base_path = self._get_base_path(user_id)
        # Use same field selection as get_emails for consistency
        select_fields = "id,subject,from,receivedDateTime,bodyPreview,isRead,conversationId,body,hasAttachments,parentFolderId"
        
        url = f"{base_path}/mailFolders/{folder_id}/messages"
        params = {
            "$select": select_fields,
            "$top": min(top, 100)  # Cap at 100
        }
        
        if include_attachments:
            params["$expand"] = "attachments"
            
        all_messages = []
        while url and len(all_messages) < top:
            response = self._get_json(url, params=params if params else None)
            messages = response.get('value', [])
            all_messages.extend(messages)
            
            # Stop if we've reached the requested count
            if len(all_messages) >= top:
                all_messages = all_messages[:top]
                break
                
            url = response.get('@odata.nextLink')
            params = None  # nextLink includes full query
            
        return {"value": all_messages}


    def move_message(self, message_id, destination_id, user_id: str = None):
        base_path = self._get_base_path(user_id)
        data = {
            "destinationId": destination_id
        }
        return requests.post(f"{base_path}/messages/{message_id}/move", json=data, headers=self._get_headers()).json()

    def delete_message(self, message_id, user_id: str = None):
        base_path = self._get_base_path(user_id)
        resp = requests.delete(f"{base_path}/messages/{message_id}", headers=self._get_headers())
        if not resp.ok:
             raise Exception(f"Failed to delete message: {resp.status_code} {resp.text}")
        return True

    # =========================================================================
    # Message Properties & Categories
    # =========================================================================

    def get_message(self, message_id: str, user_id: str = None, select: str = None):
        """Get a message by ID.

        Args:
            message_id: Message ID to fetch
            user_id: Optional delegate user email for shared mailbox
            select: Optional comma-separated list of fields to return

        Returns:
            Message object dict
        """
        base_path = self._get_base_path(user_id)
        url = f"{base_path}/messages/{message_id}"
        params = {"$select": select} if select else None
        return self._get_json(url, params=params)

    def update_message_properties(
        self,
        message_id: str,
        categories: list = None,
        flag_status: str = None,
        flag_start_datetime: dict = None,
        flag_due_datetime: dict = None,
        importance: str = None,
        is_read: bool = None,
        user_id: str = None,
    ):
        """Update message properties via PATCH.

        Args:
            message_id: Message ID to update
            categories: List of category names to set (replaces existing)
            flag_status: Flag status - 'flagged', 'complete', or 'notFlagged'
            flag_start_datetime: Start datetime for flag {"dateTime": "...", "timeZone": "..."}
            flag_due_datetime: Due datetime for flag
            importance: Importance level - 'low', 'normal', or 'high'
            is_read: Read status
            user_id: Optional delegate user email for shared mailbox

        Returns:
            Updated message object

        Raises:
            Exception: If PATCH fails
            ValueError: If no properties to update
        """
        base_path = self._get_base_path(user_id)
        url = f"{base_path}/messages/{message_id}"

        data = {}

        if categories is not None:
            data["categories"] = categories

        if importance is not None:
            data["importance"] = importance

        if is_read is not None:
            data["isRead"] = is_read

        # Build flag object if any flag-related params provided
        if flag_status is not None or flag_due_datetime is not None:
            flag_data = {}
            if flag_status is not None:
                flag_data["flagStatus"] = flag_status
            if flag_start_datetime is not None:
                flag_data["startDateTime"] = flag_start_datetime
            if flag_due_datetime is not None:
                flag_data["dueDateTime"] = flag_due_datetime
            data["flag"] = flag_data

        if not data:
            raise ValueError("No properties to update")

        resp = requests.patch(url, json=data, headers=self._get_headers())
        if not resp.ok:
            raise Exception(f"Failed to update message: {resp.status_code} {resp.text}")
        return resp.json()

    def get_master_categories(self, user_id: str = None):
        """Get all master categories.

        Args:
            user_id: Optional delegate user email for shared mailbox

        Returns:
            dict with 'value' key containing list of category objects
        """
        base_path = self._get_base_path(user_id)
        return self._get_json(f"{base_path}/outlook/masterCategories")

    def resolve_category_color(self, color: str) -> str:
        """Resolve color name or preset to preset format.

        Args:
            color: Color name (e.g., 'red', 'blue') or preset (e.g., 'preset0')

        Returns:
            Preset string (e.g., 'preset0')
        """
        if color.lower().startswith("preset"):
            return color.lower()
        return CATEGORY_COLOR_NAMES.get(color.lower(), "preset7")  # default blue

    def create_master_category(
        self,
        display_name: str,
        color: str = "preset7",
        user_id: str = None,
    ):
        """Create a new master category.

        Args:
            display_name: Category name
            color: Color preset (preset0-preset24) or color name (red, blue, etc.)
            user_id: Optional delegate user email for shared mailbox

        Returns:
            Created category object
        """
        base_path = self._get_base_path(user_id)
        resolved_color = self.resolve_category_color(color)

        data = {
            "displayName": display_name,
            "color": resolved_color
        }

        resp = requests.post(
            f"{base_path}/outlook/masterCategories",
            json=data,
            headers=self._get_headers()
        )
        if not resp.ok:
            raise Exception(f"Failed to create category: {resp.status_code} {resp.text}")
        return resp.json()

    def delete_master_category(
        self,
        category_id: str,
        user_id: str = None,
    ):
        """Delete a master category by ID.

        Args:
            category_id: Category ID to delete
            user_id: Optional delegate user email for shared mailbox

        Returns:
            True if successful

        Raises:
            Exception: If deletion fails
        """
        base_path = self._get_base_path(user_id)
        resp = requests.delete(
            f"{base_path}/outlook/masterCategories/{category_id}",
            headers=self._get_headers()
        )
        if not resp.ok:
            raise Exception(f"Failed to delete category: {resp.status_code} {resp.text}")
        return True

    def resolve_category_id(self, name_or_id: str, user_id: str = None):
        """Resolve a category name to its ID.

        Args:
            name_or_id: Category display name or ID
            user_id: Optional delegate user email

        Returns:
            Category ID if found, None otherwise
        """
        # If it looks like an ID (contains hyphen or is long), try it directly
        if "-" in name_or_id or len(name_or_id) > 50:
            return name_or_id

        # Search by name (case-sensitive as per Graph API)
        categories = self.get_master_categories(user_id)
        for cat in categories.get("value", []):
            if cat.get("displayName") == name_or_id:
                return cat.get("id")
        return None

