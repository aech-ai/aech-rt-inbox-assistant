"""
Local-only LLM observability for pydantic-ai agents.

This package provides automatic instrumentation of ALL pydantic-ai agent LLM calls
using OpenTelemetry, with a custom file-based exporter that writes to local JSONL files.

SECURITY: This package is designed to be completely local with NO data exfiltration:
- No OTLP endpoints configured
- No Logfire cloud connection
- No network calls whatsoever
- All data stays on the local filesystem

Usage:
    from aech_llm_observability import init_instrumentation, set_llm_log_path

    # Initialize once at application startup (before any pydantic-ai agents are created)
    init_instrumentation()

    # Set log path per session (thread-safe)
    set_llm_log_path(Path("/path/to/session/llm.jsonl"))

    # All pydantic-ai Agent.run() calls are now automatically logged
"""

import json
import logging
import os
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Sequence

from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider, ReadableSpan
from opentelemetry.sdk.trace.export import SpanExporter, SpanExportResult, SimpleSpanProcessor
from opentelemetry.sdk.resources import Resource

logger = logging.getLogger("aech_llm_observability")

from genai_prices import Usage as GenAIUsage, calc_price as genai_calc_price

# Thread-local storage for per-session log paths
_thread_local = threading.local()

# Global flag to prevent double initialization
_initialized = False
_init_lock = threading.Lock()

__all__ = [
    "init_instrumentation",
    "set_llm_log_path",
    "get_llm_log_path",
    "build_llm_log_path",
    "is_initialized",
    "LocalJSONLSpanExporter",
    "set_dashboard_callback",
    "get_dashboard_callback",
    "generate_usage_summary",
]

# Global callback for real-time dashboard updates
_dashboard_callback: "Callable[[dict], None] | None" = None
_dashboard_callback_lock = threading.Lock()


def set_dashboard_callback(callback: "Callable[[dict], None] | None") -> None:
    """
    Set callback for real-time dashboard updates.

    The callback receives the same dict entry that gets written to JSONL,
    allowing real-time visualization of LLM calls.

    Args:
        callback: Function that receives LLM call data dict, or None to disable.
    """
    global _dashboard_callback
    with _dashboard_callback_lock:
        _dashboard_callback = callback


def get_dashboard_callback() -> "Callable[[dict], None] | None":
    """Get the current dashboard callback."""
    return _dashboard_callback


def set_llm_log_path(path: Path | str | None) -> None:
    """
    Set the LLM log file path for the current thread/session.

    Args:
        path: Path to the JSONL log file, or None to disable logging for this thread.
    """
    _thread_local.log_path = Path(path) if path else None


def get_llm_log_path() -> Path | None:
    """Get the current thread's LLM log path."""
    return getattr(_thread_local, "log_path", None)


def build_llm_log_path(
    capability: str | None = None,
    *,
    log_path_env: str = "LLM_LOG_PATH",
    log_dir_env: str = "LLM_LOG_DIR",
    state_dir_env: str = "STATE_DIR",
    app_context_root_env: str = "AECH_APP_CONTEXT_DIR",
    default_state_dir: str = "/app/state",
    default_app_context_root: str = "/data/app_context",
    suffix: str = "-llm.jsonl",
) -> Path:
    """
    Build a timestamped LLM log path.

    Priority:
      1) LLM_LOG_PATH (exact file path)
      2) LLM_LOG_DIR (directory + timestamp filename)
      3) STATE_DIR/llm_logs
      4) AECH_APP_CONTEXT_DIR/<capability>/llm_logs
      5) /data/app_context/<capability>/llm_logs (if exists)
      6) ./data/app_context/<capability>/llm_logs (fallback)
    """
    configured_path = os.environ.get(log_path_env)
    if configured_path:
        return Path(configured_path).expanduser().resolve()

    configured_dir = os.environ.get(log_dir_env)
    if configured_dir:
        log_dir = Path(configured_dir)
    else:
        state_dir = os.environ.get(state_dir_env)
        if state_dir:
            log_dir = Path(state_dir) / "llm_logs"
        else:
            app_context_root = os.environ.get(app_context_root_env)
            if app_context_root and capability:
                log_dir = Path(app_context_root) / capability / "llm_logs"
            elif capability:
                default_root = Path(default_app_context_root)
                if default_root.exists():
                    log_dir = default_root / capability / "llm_logs"
                else:
                    log_dir = Path.cwd() / "data" / "app_context" / capability / "llm_logs"
            else:
                log_dir = Path.cwd() / "llm_logs"

    timestamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
    return log_dir / f"{timestamp}{suffix}"


class LocalJSONLSpanExporter(SpanExporter):
    """
    OpenTelemetry SpanExporter that writes pydantic-ai LLM spans to local JSONL files.

    SECURITY: This exporter:
    - Only writes to local filesystem paths set via set_llm_log_path()
    - Makes NO network connections
    - Does NOT send data to any external service
    - Is completely isolated from remote observability backends
    """

    def export(self, spans: Sequence[ReadableSpan]) -> SpanExportResult:
        """Export spans to the thread-local JSONL file."""
        for span in spans:
            try:
                self._export_span(span)
            except Exception as e:
                logger.warning(f"Failed to export span: {e}")
        return SpanExportResult.SUCCESS

    def _export_span(self, span: ReadableSpan) -> None:
        """Export a single span to the appropriate log file and/or dashboard."""
        log_path = get_llm_log_path()
        callback = _dashboard_callback

        # Early exit if nothing to do
        if not log_path and not callback:
            return

        # Only log pydantic-ai / gen_ai spans
        span_name = span.name or ""
        attributes = dict(span.attributes) if span.attributes else {}

        # Filter for LLM-related spans (pydantic-ai uses gen_ai.* attributes)
        if not self._is_llm_span(span_name, attributes):
            return

        # Extract relevant data from the span
        entry = self._span_to_entry(span, attributes)
        if not entry:
            return

        # Write to JSONL file (thread-safe via append mode)
        if log_path:
            try:
                log_path.parent.mkdir(parents=True, exist_ok=True)
                with open(log_path, "a", encoding="utf-8") as f:
                    f.write(json.dumps(entry, default=str, ensure_ascii=False) + "\n")
            except Exception as e:
                logger.warning(f"Failed to write LLM log entry to {log_path}: {e}")

        # Call dashboard callback for real-time updates
        if callback:
            try:
                callback(entry)
            except Exception as e:
                logger.debug(f"Dashboard callback error: {e}")

    def _is_llm_span(self, span_name: str, attributes: dict) -> bool:
        """Check if this span represents an LLM call or tool execution."""
        # pydantic-ai spans have gen_ai.* attributes or specific span names
        if any(k.startswith("gen_ai.") for k in attributes):
            return True
        if "chat" in span_name.lower() or "llm" in span_name.lower():
            return True
        if "pydantic" in span_name.lower() and "agent" in span_name.lower():
            return True
        # Check for model request spans
        if attributes.get("gen_ai.operation.name") or attributes.get("gen_ai.request.model"):
            return True
        # Check for tool execution spans
        span_lower = span_name.lower()
        if "tool" in span_lower or "execute_tool" in span_lower or "running tool" in span_lower:
            return True
        if attributes.get("gen_ai.tool.name") or attributes.get("tool_name"):
            return True
        return False

    def _span_to_entry(self, span: ReadableSpan, attributes: dict) -> dict | None:
        """Convert an OpenTelemetry span to our JSONL entry format."""
        # Extract token usage from attributes
        # We capture ALL token types - we pay for all of them!
        input_tokens = attributes.get("gen_ai.usage.input_tokens", 0)
        output_tokens = attributes.get("gen_ai.usage.output_tokens", 0)

        # Handle different attribute naming conventions
        if not input_tokens:
            input_tokens = attributes.get("gen_ai.response.input_tokens", 0)
        if not output_tokens:
            output_tokens = attributes.get("gen_ai.response.output_tokens", 0)

        # Extract model info (check multiple attribute names for compatibility)
        model = (
            attributes.get("gen_ai.request.model") or
            attributes.get("gen_ai.response.model") or
            attributes.get("llm.model") or
            attributes.get("model") or
            "unknown"
        )

        # Extract provider info (pydantic-ai sets gen_ai.system and gen_ai.provider_name)
        # This is used for accurate cost calculation with genai-prices
        provider = (
            attributes.get("gen_ai.system") or
            attributes.get("gen_ai.provider_name") or
            None
        )

        # Extract operation type
        operation = attributes.get("gen_ai.operation.name", span.name)

        # Calculate duration
        duration_ns = span.end_time - span.start_time if span.end_time and span.start_time else 0
        duration_ms = duration_ns / 1_000_000

        # Helper to safely extract int token values from various attribute names
        def get_token_count(*attr_names: str) -> int:
            for name in attr_names:
                val = attributes.get(name)
                if val:
                    return int(val)
            return 0

        # Check if model supports reasoning (only count reasoning tokens for these)
        # OpenAI: o1, o3, gpt-5.2 with reasoning_effort
        # Anthropic: models with @thinking=true
        model_lower = model.lower() if model else ""
        is_reasoning_model = any([
            "o1" in model_lower,
            "o3" in model_lower,
            "reasoning" in model_lower,  # @reasoning_effort in model string
            "thinking" in model_lower,   # @thinking=true in model string
            # gpt-5.2 without mini (mini doesn't have reasoning)
            ("gpt-5.2" in model_lower and "mini" not in model_lower),
        ])

        # Build entry in format compatible with existing llm.jsonl
        # IMPORTANT: Capture ALL token types for cost tracking
        # - reasoning_tokens: OpenAI o1/o3 reasoning, Claude extended thinking (billed as output tokens!)
        # - cache tokens: prompt caching for reduced costs
        entry = {
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "span_id": format(span.context.span_id, "016x") if span.context else None,
            "trace_id": format(span.context.trace_id, "032x") if span.context else None,
            "operation": operation,
            "model": model,
            "provider": provider,  # For accurate cost calculation (e.g., "openai", "anthropic")
            # Core token counts
            "input_tokens": int(input_tokens) if input_tokens else 0,
            "output_tokens": int(output_tokens) if output_tokens else 0,
            # Reasoning/thinking tokens - billed at output token rates!
            # Only count for models that actually support reasoning
            # (OpenAI returns this field for all models but it's meaningless for non-reasoning models)
            "reasoning_tokens": get_token_count(
                "gen_ai.usage.details.reasoning_tokens",  # pydantic-ai format
                "gen_ai.usage.reasoning_tokens",
                "gen_ai.usage.thinking_tokens",
                "llm.usage.reasoning_tokens",
                "openai.reasoning_tokens",
                "anthropic.thinking_tokens",
            ) if is_reasoning_model else 0,
            # Cache tokens (prompt caching)
            # pydantic-ai: gen_ai.usage.details.cache_read_tokens, gen_ai.usage.details.cache_write_tokens
            # OpenAI: prompt_tokens_details.cached_tokens
            # Claude: cache_read_input_tokens, cache_creation_input_tokens
            "cache_read_tokens": get_token_count(
                "gen_ai.usage.details.cache_read_tokens",  # pydantic-ai
                "gen_ai.usage.cache_read_tokens",
                "gen_ai.usage.cache_read_input_tokens",
                "llm.usage.cache_read_input_tokens",
                "openai.cached_tokens",
                "anthropic.cache_read_input_tokens",
            ),
            "cache_creation_tokens": get_token_count(
                "gen_ai.usage.details.cache_write_tokens",  # pydantic-ai
                "gen_ai.usage.cache_creation_tokens",
                "gen_ai.usage.cache_creation_input_tokens",
                "gen_ai.usage.cache_write_tokens",
                "anthropic.cache_creation_input_tokens",
            ),
            "duration_ms": round(duration_ms, 2),
            "status": span.status.status_code.name if span.status else "UNSET",
        }

        # Calculate cost at write-time using genai-prices
        try:
            # Use provider from span, fall back to model name heuristic
            provider_id = provider or _get_provider_for_model(model)

            # Reasoning tokens are billed as output tokens
            effective_output = entry["output_tokens"] + entry["reasoning_tokens"]

            price_data = genai_calc_price(
                GenAIUsage(
                    input_tokens=entry["input_tokens"],
                    output_tokens=effective_output,
                    cache_read_tokens=entry["cache_read_tokens"] or None,
                    cache_write_tokens=entry["cache_creation_tokens"] or None,
                ),
                model_ref=model,
                provider_id=provider_id,
            )
            if price_data and price_data.total_price is not None:
                entry["cost_usd"] = round(float(price_data.total_price), 8)
        except Exception as e:
            logger.debug(f"Could not calculate price for {model}: {e}")

        # Add any error info
        if span.status and span.status.description:
            entry["error"] = span.status.description

        # Add finish reason if available
        finish_reason = attributes.get("gen_ai.response.finish_reasons")
        if finish_reason:
            entry["finish_reason"] = finish_reason

        # Extract full request/response content for evals and audit
        # pydantic-ai v2+ stores messages as span attributes (JSON-encoded)
        request_messages = None
        response_messages = None

        # Primary: pydantic-ai v2+ uses gen_ai.input.messages and gen_ai.output.messages
        input_messages_attr = attributes.get("gen_ai.input.messages")
        if input_messages_attr:
            try:
                request_messages = json.loads(input_messages_attr) if isinstance(input_messages_attr, str) else input_messages_attr
            except (json.JSONDecodeError, TypeError):
                request_messages = str(input_messages_attr)

        output_messages_attr = attributes.get("gen_ai.output.messages")
        if output_messages_attr:
            try:
                response_messages = json.loads(output_messages_attr) if isinstance(output_messages_attr, str) else output_messages_attr
            except (json.JSONDecodeError, TypeError):
                response_messages = str(output_messages_attr)

        # Also capture system instructions if present
        system_instructions = attributes.get("gen_ai.system_instructions")
        if system_instructions:
            entry["system_instructions"] = system_instructions

        # Add request/response to entry if we have them
        if request_messages:
            entry["request_messages"] = request_messages
        if response_messages:
            entry["response_messages"] = response_messages

        # Extract tool execution data if this is a tool span
        tool_name = attributes.get("gen_ai.tool.name") or attributes.get("tool_name")
        if tool_name:
            entry["tool_name"] = tool_name

            # Tool arguments (pydantic-ai v2 uses gen_ai.tool.call.arguments, v3 uses same)
            tool_args = (
                attributes.get("gen_ai.tool.call.arguments") or
                attributes.get("tool_arguments")
            )
            if tool_args:
                try:
                    entry["tool_arguments"] = json.loads(tool_args) if isinstance(tool_args, str) else tool_args
                except (json.JSONDecodeError, TypeError):
                    entry["tool_arguments"] = str(tool_args)

            # Tool result/response
            tool_result = (
                attributes.get("gen_ai.tool.call.result") or
                attributes.get("tool_response")
            )
            if tool_result:
                try:
                    entry["tool_result"] = json.loads(tool_result) if isinstance(tool_result, str) else tool_result
                except (json.JSONDecodeError, TypeError):
                    entry["tool_result"] = str(tool_result)

        return entry

    def shutdown(self) -> None:
        """Shutdown the exporter (no-op for file-based exporter)."""
        pass

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Force flush any buffered data (no-op for append-mode file writes)."""
        return True


def init_instrumentation(service_name: str = "aech-agent") -> None:
    """
    Initialize pydantic-ai instrumentation with local-only observability.

    SECURITY GUARANTEES:
    - NO OTLP endpoints are configured
    - NO Logfire connection is made
    - NO environment variables for remote endpoints are used
    - ALL data stays on the local filesystem

    This function is idempotent and thread-safe.

    Args:
        service_name: Name to identify this service in traces (default: "aech-agent")
    """
    global _initialized

    with _init_lock:
        if _initialized:
            logger.debug("LLM instrumentation already initialized")
            return

        # SECURITY: Explicitly clear any OTLP environment variables that might cause data exfiltration
        # We do NOT want any data leaving the local machine
        otel_env_vars = [
            "OTEL_EXPORTER_OTLP_ENDPOINT",
            "OTEL_EXPORTER_OTLP_TRACES_ENDPOINT",
            "OTEL_EXPORTER_OTLP_METRICS_ENDPOINT",
            "OTEL_EXPORTER_OTLP_LOGS_ENDPOINT",
            "LOGFIRE_TOKEN",
            "LOGFIRE_PROJECT_NAME",
        ]
        for var in otel_env_vars:
            if var in os.environ:
                logger.warning(f"Removing {var} environment variable to prevent data exfiltration")
                del os.environ[var]

        # Create a minimal resource (no sensitive info)
        resource = Resource.create({
            "service.name": service_name,
            "service.version": "local",
        })

        # Create TracerProvider with ONLY our local file exporter
        provider = TracerProvider(resource=resource)

        # Add our local-only JSONL exporter
        local_exporter = LocalJSONLSpanExporter()
        provider.add_span_processor(SimpleSpanProcessor(local_exporter))

        # Set as the global tracer provider
        trace.set_tracer_provider(provider)

        # Now instrument all pydantic-ai agents
        try:
            from pydantic_ai import Agent
            from pydantic_ai.models.instrumented import InstrumentationSettings

            # Configure instrumentation settings
            settings = InstrumentationSettings(
                tracer_provider=provider,
                include_content=True,  # Include prompts/responses for debugging
                include_binary_content=False,  # Skip binary data (images, etc.)
            )

            # Instrument ALL agents globally
            Agent.instrument_all(settings)
            logger.info(f"pydantic-ai instrumentation initialized (local-only, service={service_name})")

        except ImportError as e:
            logger.warning(f"Could not import pydantic-ai for instrumentation: {e}")
        except Exception as e:
            logger.warning(f"Failed to initialize pydantic-ai instrumentation: {e}")

        _initialized = True


def is_initialized() -> bool:
    """Check if instrumentation has been initialized."""
    return _initialized


def generate_usage_summary(session_path: Path) -> dict | None:
    """
    Generate a usage summary from llm.jsonl and write to usage.json.

    Reads all LLM call entries from llm.jsonl and aggregates the pre-calculated
    costs into a summary written to usage.json.

    Args:
        session_path: Path to the session directory containing llm.jsonl

    Returns:
        The usage summary dict, or None if llm.jsonl doesn't exist
    """
    llm_log_path = session_path / "llm.jsonl"
    usage_path = session_path / "usage.json"

    if not llm_log_path.exists():
        logger.debug(f"No llm.jsonl found at {llm_log_path}")
        return None

    # Read all entries from llm.jsonl
    entries = []
    try:
        with open(llm_log_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line:
                    try:
                        entries.append(json.loads(line))
                    except json.JSONDecodeError:
                        continue
    except Exception as e:
        logger.warning(f"Failed to read llm.jsonl: {e}")
        return None

    if not entries:
        logger.debug("No entries in llm.jsonl")
        return None

    # Filter to only "chat" operations (skip "agent run" duplicates and validation entries)
    chat_entries = [e for e in entries if e.get("operation") == "chat"]

    # Aggregate by model
    by_model: dict[str, dict] = {}
    total_input_tokens = 0
    total_output_tokens = 0
    total_reasoning_tokens = 0
    total_cache_read_tokens = 0
    total_cache_creation_tokens = 0
    total_cost_usd = 0.0
    total_duration_ms = 0.0

    for entry in chat_entries:
        model = entry.get("model", "unknown")
        if model == "unknown" or not model:
            continue

        input_tokens = entry.get("input_tokens", 0)
        output_tokens = entry.get("output_tokens", 0)
        reasoning_tokens = entry.get("reasoning_tokens", 0)
        cache_read_tokens = entry.get("cache_read_tokens", 0)
        cache_creation_tokens = entry.get("cache_creation_tokens", 0)
        duration_ms = entry.get("duration_ms", 0)
        entry_cost = entry.get("cost_usd", 0.0)  # Pre-calculated at write-time

        # Initialize model entry if needed
        if model not in by_model:
            by_model[model] = {
                "calls": 0,
                "input_tokens": 0,
                "output_tokens": 0,
                "reasoning_tokens": 0,
                "cache_read_tokens": 0,
                "cache_creation_tokens": 0,
                "duration_ms": 0.0,
                "cost_usd": 0.0,
            }

        # Accumulate
        by_model[model]["calls"] += 1
        by_model[model]["input_tokens"] += input_tokens
        by_model[model]["output_tokens"] += output_tokens
        by_model[model]["reasoning_tokens"] += reasoning_tokens
        by_model[model]["cache_read_tokens"] += cache_read_tokens
        by_model[model]["cache_creation_tokens"] += cache_creation_tokens
        by_model[model]["duration_ms"] += duration_ms
        by_model[model]["cost_usd"] += entry_cost

        # Totals
        total_input_tokens += input_tokens
        total_output_tokens += output_tokens
        total_reasoning_tokens += reasoning_tokens
        total_cache_read_tokens += cache_read_tokens
        total_cache_creation_tokens += cache_creation_tokens
        total_cost_usd += entry_cost
        total_duration_ms += duration_ms

    # Round costs for cleaner output
    for model_data in by_model.values():
        model_data["cost_usd"] = round(model_data["cost_usd"], 6)
        model_data["duration_ms"] = round(model_data["duration_ms"], 2)

    # Build summary
    summary = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "total": {
            "calls": len(chat_entries),
            "input_tokens": total_input_tokens,
            "output_tokens": total_output_tokens,
            "reasoning_tokens": total_reasoning_tokens,
            "cache_read_tokens": total_cache_read_tokens,
            "cache_creation_tokens": total_cache_creation_tokens,
            "duration_ms": round(total_duration_ms, 2),
            "cost_usd": round(total_cost_usd, 6),
        },
        "by_model": by_model,
    }

    # Write to usage.json
    try:
        with open(usage_path, "w", encoding="utf-8") as f:
            json.dump(summary, f, indent=2)
    except Exception as e:
        logger.warning(f"Failed to write usage.json: {e}")

    return summary


def _get_provider_for_model(model: str) -> str:
    """Map model name to provider ID for genai-prices."""
    model_lower = model.lower()

    if any(x in model_lower for x in ["gpt-", "o1", "o3", "davinci", "curie", "babbage", "ada"]):
        return "openai"
    elif any(x in model_lower for x in ["claude", "anthropic"]):
        return "anthropic"
    elif any(x in model_lower for x in ["gemini", "palm", "bard"]):
        return "google"
    elif "mistral" in model_lower or "mixtral" in model_lower:
        return "mistral"
    elif "llama" in model_lower:
        return "meta"
    else:
        # Default to openai as most models in the logs appear to be OpenAI
        return "openai"
